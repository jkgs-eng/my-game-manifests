-- Auto-Generated Blueprint for Tools Up!
local manifest = {
    appid = 1004490,
    name = "Tools Up!",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Jackbox Party Pack 6
local manifest = {
    appid = 1005300,
    name = "The Jackbox Party Pack 6",
    status = "Custom Autopilot Build"
}
return manifest

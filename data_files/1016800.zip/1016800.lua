-- Auto-Generated Blueprint for Chernobylite Complete Edition
local manifest = {
    appid = 1016800,
    name = "Chernobylite Complete Edition",
    status = "Custom Autopilot Build"
}
return manifest

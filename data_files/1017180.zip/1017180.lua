-- Auto-Generated Blueprint for The Long Drive
local manifest = {
    appid = 1017180,
    name = "The Long Drive",
    status = "Custom Autopilot Build"
}
return manifest

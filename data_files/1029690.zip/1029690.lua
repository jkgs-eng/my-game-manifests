-- Auto-Generated Blueprint for Sniper Elite 5
local manifest = {
    appid = 1029690,
    name = "Sniper Elite 5",
    status = "Custom Autopilot Build"
}
return manifest

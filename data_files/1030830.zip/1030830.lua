-- Auto-Generated Blueprint for Mafia II: Definitive Edition
local manifest = {
    appid = 1030830,
    name = "Mafia II: Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Mafia: Definitive Edition
local manifest = {
    appid = 1030840,
    name = "Mafia: Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

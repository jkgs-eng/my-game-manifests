-- Auto-Generated Blueprint for DIRT 5
local manifest = {
    appid = 1038250,
    name = "DIRT 5",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Total War: EMPIRE – Definitive Edition
local manifest = {
    appid = 10500,
    name = "Total War: EMPIRE – Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

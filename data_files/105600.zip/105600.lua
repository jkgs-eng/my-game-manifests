-- Auto-Generated Blueprint for Terraria
local manifest = {
    appid = 105600,
    name = "Terraria",
    status = "Custom Autopilot Build"
}
return manifest

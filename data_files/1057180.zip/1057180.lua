-- Auto-Generated Blueprint for Border Officer
local manifest = {
    appid = 1057180,
    name = "Border Officer",
    status = "Custom Autopilot Build"
}
return manifest

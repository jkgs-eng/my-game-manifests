-- Auto-Generated Blueprint for Streamer Daily
local manifest = {
    appid = 1058380,
    name = "Streamer Daily",
    status = "Custom Autopilot Build"
}
return manifest

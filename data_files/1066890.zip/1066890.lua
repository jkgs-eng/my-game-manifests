-- Auto-Generated Blueprint for Automobilista 2
local manifest = {
    appid = 1066890,
    name = "Automobilista 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Arma 3
local manifest = {
    appid = 107410,
    name = "Arma 3",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Destiny 2
local manifest = {
    appid = 1085660,
    name = "Destiny 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Project Zomboid
local manifest = {
    appid = 108600,
    name = "Project Zomboid",
    status = "Custom Autopilot Build"
}
return manifest

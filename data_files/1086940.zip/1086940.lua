-- Auto-Generated Blueprint for Baldur's Gate 3
local manifest = {
    appid = 1086940,
    name = "Baldur's Gate 3",
    status = "Custom Autopilot Build"
}
return manifest

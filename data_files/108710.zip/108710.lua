-- Auto-Generated Blueprint for Alan Wake
local manifest = {
    appid = 108710,
    name = "Alan Wake",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Yakuza 3 Remastered
local manifest = {
    appid = 1088710,
    name = "Yakuza 3 Remastered",
    status = "Custom Autopilot Build"
}
return manifest

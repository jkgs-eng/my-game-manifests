-- Auto-Generated Blueprint for Cyberpunk 2077
local manifest = {
    appid = 1091500,
    name = "Cyberpunk 2077",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Inscryption
local manifest = {
    appid = 1092790,
    name = "Inscryption",
    status = "Custom Autopilot Build"
}
return manifest

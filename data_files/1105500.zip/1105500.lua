-- Auto-Generated Blueprint for Yakuza 4 Remastered
local manifest = {
    appid = 1105500,
    name = "Yakuza 4 Remastered",
    status = "Custom Autopilot Build"
}
return manifest

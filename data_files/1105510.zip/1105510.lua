-- Auto-Generated Blueprint for Yakuza 5 Remastered
local manifest = {
    appid = 1105510,
    name = "Yakuza 5 Remastered",
    status = "Custom Autopilot Build"
}
return manifest

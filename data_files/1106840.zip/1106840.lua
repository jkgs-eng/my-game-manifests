-- Auto-Generated Blueprint for Hydroneer
local manifest = {
    appid = 1106840,
    name = "Hydroneer",
    status = "Custom Autopilot Build"
}
return manifest

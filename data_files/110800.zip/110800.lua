-- Auto-Generated Blueprint for L.A. Noire
local manifest = {
    appid = 110800,
    name = "L.A. Noire",
    status = "Custom Autopilot Build"
}
return manifest

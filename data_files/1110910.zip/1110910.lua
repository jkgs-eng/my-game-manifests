-- Auto-Generated Blueprint for Mortal Shell
local manifest = {
    appid = 1110910,
    name = "Mortal Shell",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Persona 4 Golden
local manifest = {
    appid = 1113000,
    name = "Persona 4 Golden",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Monster Hunter World: Iceborne
local manifest = {
    appid = 1118010,
    name = "Monster Hunter World: Iceborne",
    status = "Custom Autopilot Build"
}
return manifest

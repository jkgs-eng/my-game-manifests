-- Auto-Generated Blueprint for Ranch Simulator: Build, Hunt, Farm
local manifest = {
    appid = 1119730,
    name = "Ranch Simulator: Build, Hunt, Farm",
    status = "Custom Autopilot Build"
}
return manifest

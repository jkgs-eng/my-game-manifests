-- Auto-Generated Blueprint for Medieval Dynasty
local manifest = {
    appid = 1129580,
    name = "Medieval Dynasty",
    status = "Custom Autopilot Build"
}
return manifest

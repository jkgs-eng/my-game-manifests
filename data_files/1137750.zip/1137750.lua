-- Auto-Generated Blueprint for Farmer's Life
local manifest = {
    appid = 1137750,
    name = "Farmer's Life",
    status = "Custom Autopilot Build"
}
return manifest

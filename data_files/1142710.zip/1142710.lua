-- Auto-Generated Blueprint for Total War: WARHAMMER III
local manifest = {
    appid = 1142710,
    name = "Total War: WARHAMMER III",
    status = "Custom Autopilot Build"
}
return manifest

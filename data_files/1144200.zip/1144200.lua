-- Auto-Generated Blueprint for Ready or Not
local manifest = {
    appid = 1144200,
    name = "Ready or Not",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Hades II
local manifest = {
    appid = 1145350,
    name = "Hades II",
    status = "Custom Autopilot Build"
}
return manifest

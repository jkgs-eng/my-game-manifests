-- Auto-Generated Blueprint for Skul: The Hero Slayer
local manifest = {
    appid = 1147560,
    name = "Skul: The Hero Slayer",
    status = "Custom Autopilot Build"
}
return manifest

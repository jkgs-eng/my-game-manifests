-- Auto-Generated Blueprint for Gas Station Simulator
local manifest = {
    appid = 1149620,
    name = "Gas Station Simulator",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Fallout 76
local manifest = {
    appid = 1151340,
    name = "Fallout 76",
    status = "Custom Autopilot Build"
}
return manifest

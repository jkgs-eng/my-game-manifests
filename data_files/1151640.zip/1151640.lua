-- Auto-Generated Blueprint for Horizon Zero Dawn™ Complete Edition
local manifest = {
    appid = 1151640,
    name = "Horizon Zero Dawn™ Complete Edition",
    status = "Custom Autopilot Build"
}
return manifest

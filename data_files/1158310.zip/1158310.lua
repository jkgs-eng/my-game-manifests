-- Auto-Generated Blueprint for Crusader Kings III
local manifest = {
    appid = 1158310,
    name = "Crusader Kings III",
    status = "Custom Autopilot Build"
}
return manifest

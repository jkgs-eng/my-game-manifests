-- Auto-Generated Blueprint for Apex Legends™
local manifest = {
    appid = 1172470,
    name = "Apex Legends™",
    status = "Custom Autopilot Build"
}
return manifest

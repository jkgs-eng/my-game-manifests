-- Auto-Generated Blueprint for Sea of Thieves: 2026 Edition
local manifest = {
    appid = 1172620,
    name = "Sea of Thieves: 2026 Edition",
    status = "Autopilot Baseline"
}
return manifest

-- Auto-Generated Blueprint for Red Dead Redemption 2
local manifest = {
    appid = 1174180,
    name = "Red Dead Redemption 2",
    status = "Custom Autopilot Build"
}
return manifest

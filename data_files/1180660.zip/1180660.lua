-- Auto-Generated Blueprint for Tell Me Why
local manifest = {
    appid = 1180660,
    name = "Tell Me Why",
    status = "Custom Autopilot Build"
}
return manifest

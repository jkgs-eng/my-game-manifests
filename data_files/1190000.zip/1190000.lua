-- Auto-Generated Blueprint for Car Mechanic Simulator 2021
local manifest = {
    appid = 1190000,
    name = "Car Mechanic Simulator 2021",
    status = "Custom Autopilot Build"
}
return manifest

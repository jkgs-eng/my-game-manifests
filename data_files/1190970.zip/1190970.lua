-- Auto-Generated Blueprint for House Flipper 2
local manifest = {
    appid = 1190970,
    name = "House Flipper 2",
    status = "Custom Autopilot Build"
}
return manifest

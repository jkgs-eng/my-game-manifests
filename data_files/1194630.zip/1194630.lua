-- Auto-Generated Blueprint for The Dark Pictures Anthology: Little Hope
local manifest = {
    appid = 1194630,
    name = "The Dark Pictures Anthology: Little Hope",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Resident Evil Village
local manifest = {
    appid = 1196590,
    name = "Resident Evil Village",
    status = "Custom Autopilot Build"
}
return manifest

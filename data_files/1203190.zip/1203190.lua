-- Auto-Generated Blueprint for Wreckfest 2
local manifest = {
    appid = 1203190,
    name = "Wreckfest 2",
    status = "Custom Autopilot Build"
}
return manifest

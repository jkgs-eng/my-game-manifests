-- Auto-Generated Blueprint for Enshrouded
local manifest = {
    appid = 1203620,
    name = "Enshrouded",
    status = "Custom Autopilot Build"
}
return manifest

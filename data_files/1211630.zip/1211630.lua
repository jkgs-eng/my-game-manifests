-- Auto-Generated Blueprint for The Jackbox Party Pack 7
local manifest = {
    appid = 1211630,
    name = "The Jackbox Party Pack 7",
    status = "Custom Autopilot Build"
}
return manifest

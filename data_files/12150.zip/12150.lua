-- Auto-Generated Blueprint for Max Payne 2: The Fall of Max Payne
local manifest = {
    appid = 12150,
    name = "Max Payne 2: The Fall of Max Payne",
    status = "Custom Autopilot Build"
}
return manifest

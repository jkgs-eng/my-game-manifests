-- Auto-Generated Blueprint for Grand Theft Auto IV: The Complete Edition
local manifest = {
    appid = 12210,
    name = "Grand Theft Auto IV: The Complete Edition",
    status = "Custom Autopilot Build"
}
return manifest

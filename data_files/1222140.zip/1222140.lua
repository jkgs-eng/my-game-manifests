-- Auto-Generated Blueprint for Detroit: Become Human
local manifest = {
    appid = 1222140,
    name = "Detroit: Become Human",
    status = "Custom Autopilot Build"
}
return manifest

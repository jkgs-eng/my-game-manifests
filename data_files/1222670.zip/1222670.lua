-- Auto-Generated Blueprint for The Sims™ 4
local manifest = {
    appid = 1222670,
    name = "The Sims™ 4",
    status = "Custom Autopilot Build"
}
return manifest

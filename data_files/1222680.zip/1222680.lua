-- Auto-Generated Blueprint for Need for Speed™ Heat
local manifest = {
    appid = 1222680,
    name = "Need for Speed™ Heat",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for A Way Out
local manifest = {
    appid = 1222700,
    name = "A Way Out",
    status = "Custom Autopilot Build"
}
return manifest

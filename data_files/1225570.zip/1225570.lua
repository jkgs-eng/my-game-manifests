-- Auto-Generated Blueprint for Unravel Two
local manifest = {
    appid = 1225570,
    name = "Unravel Two",
    status = "Custom Autopilot Build"
}
return manifest

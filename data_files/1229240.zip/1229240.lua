-- Auto-Generated Blueprint for Chained Echoes
local manifest = {
    appid = 1229240,
    name = "Chained Echoes",
    status = "Custom Autopilot Build"
}
return manifest

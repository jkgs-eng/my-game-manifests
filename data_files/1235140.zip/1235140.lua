-- Auto-Generated Blueprint for Yakuza: Like a Dragon
local manifest = {
    appid = 1235140,
    name = "Yakuza: Like a Dragon",
    status = "Custom Autopilot Build"
}
return manifest

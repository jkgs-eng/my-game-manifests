-- Auto-Generated Blueprint for Overcooked! All You Can Eat
local manifest = {
    appid = 1243830,
    name = "Overcooked! All You Can Eat",
    status = "Custom Autopilot Build"
}
return manifest

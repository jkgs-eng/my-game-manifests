-- Auto-Generated Blueprint for Sea of Stars: Sunset Edition
local manifest = {
    appid = 1244090,
    name = "Sea of Stars: Sunset Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for ELDEN RING
local manifest = {
    appid = 1245620,
    name = "ELDEN RING",
    status = "Custom Autopilot Build"
}
return manifest

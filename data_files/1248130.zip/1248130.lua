-- Auto-Generated Blueprint for Farming Simulator 22
local manifest = {
    appid = 1248130,
    name = "Farming Simulator 22",
    status = "Custom Autopilot Build"
}
return manifest

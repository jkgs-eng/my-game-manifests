-- Auto-Generated Blueprint for DEATHLOOP
local manifest = {
    appid = 1252330,
    name = "DEATHLOOP",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Rogue Legacy 2
local manifest = {
    appid = 1253920,
    name = "Rogue Legacy 2",
    status = "Custom Autopilot Build"
}
return manifest

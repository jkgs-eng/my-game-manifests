-- Auto-Generated Blueprint for Prison Architect 2
local manifest = {
    appid = 1257610,
    name = "Prison Architect 2",
    status = "Custom Autopilot Build"
}
return manifest

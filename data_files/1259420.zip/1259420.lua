-- Auto-Generated Blueprint for Days Gone
local manifest = {
    appid = 1259420,
    name = "Days Gone",
    status = "Custom Autopilot Build"
}
return manifest

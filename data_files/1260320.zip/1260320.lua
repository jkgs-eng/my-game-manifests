-- Auto-Generated Blueprint for Party Animals
local manifest = {
    appid = 1260320,
    name = "Party Animals",
    status = "Custom Autopilot Build"
}
return manifest

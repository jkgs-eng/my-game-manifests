-- Auto-Generated Blueprint for PAYDAY 3
local manifest = {
    appid = 1272080,
    name = "PAYDAY 3",
    status = "Custom Autopilot Build"
}
return manifest

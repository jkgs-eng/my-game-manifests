-- Auto-Generated Blueprint for Diplomacy is Not an Option
local manifest = {
    appid = 1272320,
    name = "Diplomacy is Not an Option",
    status = "Custom Autopilot Build"
}
return manifest

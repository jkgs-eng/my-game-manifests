-- Auto-Generated Blueprint for Construction Simulator
local manifest = {
    appid = 1273400,
    name = "Construction Simulator",
    status = "Custom Autopilot Build"
}
return manifest

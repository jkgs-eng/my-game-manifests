-- Auto-Generated Blueprint for DEVOUR
local manifest = {
    appid = 1274570,
    name = "DEVOUR",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Monster Hunter Stories 2: Wings of Ruin
local manifest = {
    appid = 1277400,
    name = "Monster Hunter Stories 2: Wings of Ruin",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Dark Pictures Anthology: House of Ashes
local manifest = {
    appid = 1281590,
    name = "The Dark Pictures Anthology: House of Ashes",
    status = "Custom Autopilot Build"
}
return manifest

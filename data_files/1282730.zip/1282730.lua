-- Auto-Generated Blueprint for Loop Hero
local manifest = {
    appid = 1282730,
    name = "Loop Hero",
    status = "Custom Autopilot Build"
}
return manifest

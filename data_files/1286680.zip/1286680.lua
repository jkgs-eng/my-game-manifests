-- Auto-Generated Blueprint for Tiny Tina's Wonderlands
local manifest = {
    appid = 1286680,
    name = "Tiny Tina's Wonderlands",
    status = "Custom Autopilot Build"
}
return manifest

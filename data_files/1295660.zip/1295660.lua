-- Auto-Generated Blueprint for Sid Meier's Civilization VII
local manifest = {
    appid = 1295660,
    name = "Sid Meier's Civilization VII",
    status = "Custom Autopilot Build"
}
return manifest

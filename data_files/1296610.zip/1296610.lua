-- Auto-Generated Blueprint for Peglin
local manifest = {
    appid = 1296610,
    name = "Peglin",
    status = "Custom Autopilot Build"
}
return manifest

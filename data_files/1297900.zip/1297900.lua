-- Auto-Generated Blueprint for Gothic 1 Remake
local manifest = {
    appid = 1297900,
    name = "Gothic 1 Remake",
    status = "Custom Autopilot Build"
}
return manifest

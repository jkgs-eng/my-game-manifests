-- Auto-Generated Blueprint for Labyrinthine
local manifest = {
    appid = 1302240,
    name = "Labyrinthine",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Outlast Trials
local manifest = {
    appid = 1304930,
    name = "The Outlast Trials",
    status = "Custom Autopilot Build"
}
return manifest

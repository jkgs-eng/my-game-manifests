-- Auto-Generated Blueprint for GRID Legends
local manifest = {
    appid = 1307710,
    name = "GRID Legends",
    status = "Custom Autopilot Build"
}
return manifest

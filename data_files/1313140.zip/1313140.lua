-- Auto-Generated Blueprint for Cult of the Lamb
local manifest = {
    appid = 1313140,
    name = "Cult of the Lamb",
    status = "Custom Autopilot Build"
}
return manifest

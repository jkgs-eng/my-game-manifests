-- Auto-Generated Blueprint for Terraria: Otherworld Official Soundtrack
local manifest = {
    appid = 1323320,
    name = "Terraria: Otherworld Official Soundtrack",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Sons Of The Forest
local manifest = {
    appid = 1326470,
    name = "Sons Of The Forest",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Need for Speed™ Hot Pursuit Remastered
local manifest = {
    appid = 1328660,
    name = "Need for Speed™ Hot Pursuit Remastered",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Big Ambitions
local manifest = {
    appid = 1331550,
    name = "Big Ambitions",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Thief Simulator 2
local manifest = {
    appid = 1332720,
    name = "Thief Simulator 2",
    status = "Custom Autopilot Build"
}
return manifest

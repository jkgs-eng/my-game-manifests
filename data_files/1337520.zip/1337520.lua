-- Auto-Generated Blueprint for Risk of Rain Returns
local manifest = {
    appid = 1337520,
    name = "Risk of Rain Returns",
    status = "Custom Autopilot Build"
}
return manifest

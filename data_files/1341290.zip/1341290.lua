-- Auto-Generated Blueprint for We Were Here Forever
local manifest = {
    appid = 1341290,
    name = "We Were Here Forever",
    status = "Custom Autopilot Build"
}
return manifest

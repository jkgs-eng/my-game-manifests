-- Auto-Generated Blueprint for As Dusk Falls
local manifest = {
    appid = 1341820,
    name = "As Dusk Falls",
    status = "Custom Autopilot Build"
}
return manifest

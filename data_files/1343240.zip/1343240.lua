-- Auto-Generated Blueprint for Thymesia
local manifest = {
    appid = 1343240,
    name = "Thymesia",
    status = "Custom Autopilot Build"
}
return manifest

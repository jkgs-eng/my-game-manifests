-- Auto-Generated Blueprint for STRANGER OF PARADISE FINAL FANTASY ORIGIN
local manifest = {
    appid = 1358700,
    name = "STRANGER OF PARADISE FINAL FANTASY ORIGIN",
    status = "Custom Autopilot Build"
}
return manifest

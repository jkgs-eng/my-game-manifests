-- Auto-Generated Blueprint for Zero Hour
local manifest = {
    appid = 1359090,
    name = "Zero Hour",
    status = "Custom Autopilot Build"
}
return manifest

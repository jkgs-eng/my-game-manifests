-- Auto-Generated Blueprint for Warhammer 40,000: Darktide
local manifest = {
    appid = 1361210,
    name = "Warhammer 40,000: Darktide",
    status = "Custom Autopilot Build"
}
return manifest

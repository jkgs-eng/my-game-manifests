-- Auto-Generated Blueprint for Manor Lords
local manifest = {
    appid = 1363080,
    name = "Manor Lords",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Street Fighter™ 6
local manifest = {
    appid = 1364780,
    name = "Street Fighter™ 6",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Dyson Sphere Program
local manifest = {
    appid = 1366540,
    name = "Dyson Sphere Program",
    status = "Custom Autopilot Build"
}
return manifest

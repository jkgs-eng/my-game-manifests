-- Auto-Generated Blueprint for GUILTY GEAR -STRIVE-
local manifest = {
    appid = 1384160,
    name = "GUILTY GEAR -STRIVE-",
    status = "Custom Autopilot Build"
}
return manifest

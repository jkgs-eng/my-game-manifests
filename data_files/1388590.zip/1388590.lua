-- Auto-Generated Blueprint for Yakuza 6: The Song of Life
local manifest = {
    appid = 1388590,
    name = "Yakuza 6: The Song of Life",
    status = "Custom Autopilot Build"
}
return manifest

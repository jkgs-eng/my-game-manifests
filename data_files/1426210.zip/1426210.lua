-- Auto-Generated Blueprint for It Takes Two
local manifest = {
    appid = 1426210,
    name = "It Takes Two",
    status = "Custom Autopilot Build"
}
return manifest

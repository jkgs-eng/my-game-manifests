-- Auto-Generated Blueprint for Age of Darkness: Final Stand
local manifest = {
    appid = 1426450,
    name = "Age of Darkness: Final Stand",
    status = "Custom Autopilot Build"
}
return manifest

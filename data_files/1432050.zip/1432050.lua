-- Auto-Generated Blueprint for Nobody Saves the World
local manifest = {
    appid = 1432050,
    name = "Nobody Saves the World",
    status = "Custom Autopilot Build"
}
return manifest

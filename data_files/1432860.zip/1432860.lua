-- Auto-Generated Blueprint for Sun Haven
local manifest = {
    appid = 1432860,
    name = "Sun Haven",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Texas Chain Saw Massacre
local manifest = {
    appid = 1433140,
    name = "The Texas Chain Saw Massacre",
    status = "Custom Autopilot Build"
}
return manifest

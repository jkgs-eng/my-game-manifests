-- Auto-Generated Blueprint for Trine 5: A Clockwork Conspiracy
local manifest = {
    appid = 1436700,
    name = "Trine 5: A Clockwork Conspiracy",
    status = "Custom Autopilot Build"
}
return manifest

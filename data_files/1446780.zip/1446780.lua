-- Auto-Generated Blueprint for MONSTER HUNTER RISE
local manifest = {
    appid = 1446780,
    name = "MONSTER HUNTER RISE",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Wo Long: Fallen Dynasty
local manifest = {
    appid = 1448440,
    name = "Wo Long: Fallen Dynasty",
    status = "Custom Autopilot Build"
}
return manifest

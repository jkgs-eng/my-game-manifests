-- Auto-Generated Blueprint for The Outer Worlds 2
local manifest = {
    appid = 1449110,
    name = "The Outer Worlds 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Monsters & Mortals - Monstrum
local manifest = {
    appid = 1450740,
    name = "Monsters & Mortals - Monstrum",
    status = "Custom Autopilot Build"
}
return manifest

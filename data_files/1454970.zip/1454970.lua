-- Auto-Generated Blueprint for New Tales from the Borderlands
local manifest = {
    appid = 1454970,
    name = "New Tales from the Borderlands",
    status = "Custom Autopilot Build"
}
return manifest

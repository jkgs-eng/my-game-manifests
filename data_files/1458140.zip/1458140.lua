-- Auto-Generated Blueprint for Pacific Drive
local manifest = {
    appid = 1458140,
    name = "Pacific Drive",
    status = "Custom Autopilot Build"
}
return manifest

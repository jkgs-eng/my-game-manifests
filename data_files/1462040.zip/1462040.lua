-- Auto-Generated Blueprint for FINAL FANTASY VII REMAKE INTERGRADE
local manifest = {
    appid = 1462040,
    name = "FINAL FANTASY VII REMAKE INTERGRADE",
    status = "Custom Autopilot Build"
}
return manifest

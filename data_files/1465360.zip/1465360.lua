-- Auto-Generated Blueprint for SnowRunner
local manifest = {
    appid = 1465360,
    name = "SnowRunner",
    status = "Custom Autopilot Build"
}
return manifest

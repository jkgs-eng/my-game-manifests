-- Auto-Generated Blueprint for American Truck Simulator - Texas
local manifest = {
    appid = 1465750,
    type = "appid",
    name = "American Truck Simulator - Texas",
    status = "Custom Autopilot Build"
}
return manifest

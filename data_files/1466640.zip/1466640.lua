-- Auto-Generated Blueprint for Road 96 🛣️
local manifest = {
    appid = 1466640,
    name = "Road 96 🛣️",
    status = "Custom Autopilot Build"
}
return manifest

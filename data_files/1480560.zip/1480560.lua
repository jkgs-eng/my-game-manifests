-- Auto-Generated Blueprint for Lawn Mowing Simulator
local manifest = {
    appid = 1480560,
    name = "Lawn Mowing Simulator",
    status = "Custom Autopilot Build"
}
return manifest

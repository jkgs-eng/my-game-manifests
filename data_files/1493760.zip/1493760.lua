-- Auto-Generated Blueprint for Youtubers Life 2
local manifest = {
    appid = 1493760,
    name = "Youtubers Life 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for What The Dub?!
local manifest = {
    appid = 1495860,
    name = "What The Dub?!",
    status = "Custom Autopilot Build"
}
return manifest

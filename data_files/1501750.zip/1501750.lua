-- Auto-Generated Blueprint for Lords of the Fallen
local manifest = {
    appid = 1501750,
    name = "Lords of the Fallen",
    status = "Custom Autopilot Build"
}
return manifest

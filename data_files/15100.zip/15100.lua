-- Auto-Generated Blueprint for Assassin's Creed™: Director's Cut Edition
local manifest = {
    appid = 15100,
    name = "Assassin's Creed™: Director's Cut Edition",
    status = "Custom Autopilot Build"
}
return manifest

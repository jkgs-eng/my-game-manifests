-- Auto-Generated Blueprint for The Past Within
local manifest = {
    appid = 1515210,
    name = "The Past Within",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Mon Bazou
local manifest = {
    appid = 1520370,
    name = "Mon Bazou",
    status = "Custom Autopilot Build"
}
return manifest

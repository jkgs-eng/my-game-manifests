-- Auto-Generated Blueprint for Grand Theft Auto III – The Definitive Edition
local manifest = {
    appid = 1546970,
    name = "Grand Theft Auto III – The Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Grand Theft Auto: Vice City – The Definitive Edition
local manifest = {
    appid = 1546990,
    name = "Grand Theft Auto: Vice City – The Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

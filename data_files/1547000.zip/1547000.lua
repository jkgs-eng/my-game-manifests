-- Auto-Generated Blueprint for Grand Theft Auto: San Andreas – The Definitive Edition
local manifest = {
    appid = 1547000,
    name = "Grand Theft Auto: San Andreas – The Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

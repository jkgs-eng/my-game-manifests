-- Auto-Generated Blueprint for Aliens: Fireteam Elite
local manifest = {
    appid = 1549970,
    name = "Aliens: Fireteam Elite",
    status = "Custom Autopilot Build"
}
return manifest

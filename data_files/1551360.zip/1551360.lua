-- Auto-Generated Blueprint for Forza Horizon 5
local manifest = {
    appid = 1551360,
    name = "Forza Horizon 5",
    status = "Custom Autopilot Build"
}
return manifest

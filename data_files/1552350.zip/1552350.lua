-- Auto-Generated Blueprint for The Jackbox Party Pack 8
local manifest = {
    appid = 1552350,
    name = "The Jackbox Party Pack 8",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for FOREWARNED
local manifest = {
    appid = 1562420,
    name = "FOREWARNED",
    status = "Custom Autopilot Build"
}
return manifest

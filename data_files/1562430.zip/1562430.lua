-- Auto-Generated Blueprint for DREDGE
local manifest = {
    appid = 1562430,
    name = "DREDGE",
    status = "Custom Autopilot Build"
}
return manifest

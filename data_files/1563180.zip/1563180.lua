-- Auto-Generated Blueprint for Internet Cafe Simulator 2
local manifest = {
    appid = 1563180,
    name = "Internet Cafe Simulator 2",
    status = "Custom Autopilot Build"
}
return manifest

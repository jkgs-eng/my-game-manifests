-- Auto-Generated Blueprint for The Dark Pictures Anthology: The Devil in Me
local manifest = {
    appid = 1567020,
    name = "The Dark Pictures Anthology: The Devil in Me",
    status = "Custom Autopilot Build"
}
return manifest

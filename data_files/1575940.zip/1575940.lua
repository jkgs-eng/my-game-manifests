-- Auto-Generated Blueprint for Sins of a Solar Empire II
local manifest = {
    appid = 1575940,
    name = "Sins of a Solar Empire II",
    status = "Custom Autopilot Build"
}
return manifest

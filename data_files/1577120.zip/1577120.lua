-- Auto-Generated Blueprint for The Quarry
local manifest = {
    appid = 1577120,
    name = "The Quarry",
    status = "Custom Autopilot Build"
}
return manifest

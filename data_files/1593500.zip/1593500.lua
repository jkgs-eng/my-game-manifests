-- Auto-Generated Blueprint for God of War
local manifest = {
    appid = 1593500,
    name = "God of War",
    status = "Custom Autopilot Build"
}
return manifest

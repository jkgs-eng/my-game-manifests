-- Auto-Generated Blueprint for Frostpunk 2
local manifest = {
    appid = 1601580,
    name = "Frostpunk 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Dune: Spice Wars
local manifest = {
    appid = 1605220,
    name = "Dune: Spice Wars",
    status = "Custom Autopilot Build"
}
return manifest

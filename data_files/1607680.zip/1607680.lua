-- Auto-Generated Blueprint for Bread & Fred
local manifest = {
    appid = 1607680,
    name = "Bread & Fred",
    status = "Custom Autopilot Build"
}
return manifest

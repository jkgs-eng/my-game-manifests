-- Auto-Generated Blueprint for Core Keeper
local manifest = {
    appid = 1621690,
    name = "Core Keeper",
    status = "Custom Autopilot Build"
}
return manifest

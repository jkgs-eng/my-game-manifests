-- Auto-Generated Blueprint for Palworld
local manifest = {
    appid = 1623730,
    name = "Palworld",
    status = "Custom Autopilot Build"
}
return manifest

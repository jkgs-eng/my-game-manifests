-- Auto-Generated Blueprint for Lies of P
local manifest = {
    appid = 1627720,
    name = "Lies of P",
    status = "Custom Autopilot Build"
}
return manifest

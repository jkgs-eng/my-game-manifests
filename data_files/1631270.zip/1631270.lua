-- Auto-Generated Blueprint for StarRupture
local manifest = {
    appid = 1631270,
    name = "StarRupture",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Moving Out 2
local manifest = {
    appid = 1641700,
    name = "Moving Out 2",
    status = "Custom Autopilot Build"
}
return manifest

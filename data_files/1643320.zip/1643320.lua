-- Auto-Generated Blueprint for S.T.A.L.K.E.R. 2: Heart of Chornobyl
local manifest = {
    appid = 1643320,
    name = "S.T.A.L.K.E.R. 2: Heart of Chornobyl",
    status = "Custom Autopilot Build"
}
return manifest

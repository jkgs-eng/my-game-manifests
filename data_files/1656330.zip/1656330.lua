-- Auto-Generated Blueprint for Destiny 2: The Witch Queen
local manifest = {
    appid = 1656330,
    type = "appid",
    name = "Destiny 2: The Witch Queen",
    status = "Custom Autopilot Build"
}
return manifest

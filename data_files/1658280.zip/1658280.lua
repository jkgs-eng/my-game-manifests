-- Auto-Generated Blueprint for Eiyuden Chronicle: Hundred Heroes
local manifest = {
    appid = 1658280,
    name = "Eiyuden Chronicle: Hundred Heroes",
    status = "Custom Autopilot Build"
}
return manifest

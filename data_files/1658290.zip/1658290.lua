-- Auto-Generated Blueprint for Eiyuden Chronicle: Rising
local manifest = {
    appid = 1658290,
    name = "Eiyuden Chronicle: Rising",
    status = "Custom Autopilot Build"
}
return manifest

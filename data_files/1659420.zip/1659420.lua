-- Auto-Generated Blueprint for UNCHARTED™: Legacy of Thieves Collection
local manifest = {
    appid = 1659420,
    name = "UNCHARTED™: Legacy of Thieves Collection",
    status = "Custom Autopilot Build"
}
return manifest

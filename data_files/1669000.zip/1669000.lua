-- Auto-Generated Blueprint for Age of Wonders 4
local manifest = {
    appid = 1669000,
    name = "Age of Wonders 4",
    status = "Custom Autopilot Build"
}
return manifest

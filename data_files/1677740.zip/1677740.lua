-- Auto-Generated Blueprint for Stumble Guys
local manifest = {
    appid = 1677740,
    name = "Stumble Guys",
    status = "Custom Autopilot Build"
}
return manifest

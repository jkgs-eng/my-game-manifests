-- Auto-Generated Blueprint for Persona 5 Royal
local manifest = {
    appid = 1687950,
    name = "Persona 5 Royal",
    status = "Custom Autopilot Build"
}
return manifest

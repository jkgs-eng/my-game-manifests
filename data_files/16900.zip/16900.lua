-- Auto-Generated Blueprint for GROUND BRANCH
local manifest = {
    appid = 16900,
    name = "GROUND BRANCH",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Sengoku Dynasty
local manifest = {
    appid = 1702010,
    name = "Sengoku Dynasty",
    status = "Custom Autopilot Build"
}
return manifest

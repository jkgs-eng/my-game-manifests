-- Auto-Generated Blueprint for Drug Dealer Simulator 2
local manifest = {
    appid = 1708850,
    name = "Drug Dealer Simulator 2",
    status = "Custom Autopilot Build"
}
return manifest

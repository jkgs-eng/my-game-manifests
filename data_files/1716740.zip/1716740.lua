-- Auto-Generated Blueprint for Starfield
local manifest = {
    appid = 1716740,
    name = "Starfield",
    status = "Custom Autopilot Build"
}
return manifest

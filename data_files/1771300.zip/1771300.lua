-- Auto-Generated Blueprint for Kingdom Come: Deliverance II
local manifest = {
    appid = 1771300,
    name = "Kingdom Come: Deliverance II",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for TEKKEN 8
local manifest = {
    appid = 1778820,
    name = "TEKKEN 8",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Vampire Survivors
local manifest = {
    appid = 1794680,
    name = "Vampire Survivors",
    status = "Custom Autopilot Build"
}
return manifest

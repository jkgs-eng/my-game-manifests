-- Auto-Generated Blueprint for Bellwright
local manifest = {
    appid = 1812450,
    name = "Bellwright",
    status = "Custom Autopilot Build"
}
return manifest

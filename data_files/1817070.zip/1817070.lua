-- Auto-Generated Blueprint for Marvel’s Spider-Man Remastered
local manifest = {
    appid = 1817070,
    name = "Marvel’s Spider-Man Remastered",
    status = "Custom Autopilot Build"
}
return manifest

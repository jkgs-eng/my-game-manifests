-- Auto-Generated Blueprint for Marvel’s Spider-Man: Miles Morales
local manifest = {
    appid = 1817190,
    name = "Marvel’s Spider-Man: Miles Morales",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Chivalry 2
local manifest = {
    appid = 1824220,
    name = "Chivalry 2",
    status = "Custom Autopilot Build"
}
return manifest

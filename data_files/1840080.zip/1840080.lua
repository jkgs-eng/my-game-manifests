-- Auto-Generated Blueprint for Homeworld 3
local manifest = {
    appid = 1840080,
    name = "Homeworld 3",
    status = "Custom Autopilot Build"
}
return manifest

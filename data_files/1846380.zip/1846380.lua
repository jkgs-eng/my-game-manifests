-- Auto-Generated Blueprint for Need for Speed™ Unbound
local manifest = {
    appid = 1846380,
    name = "Need for Speed™ Unbound",
    status = "Custom Autopilot Build"
}
return manifest

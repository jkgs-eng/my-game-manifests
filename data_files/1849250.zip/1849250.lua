-- Auto-Generated Blueprint for EA SPORTS™ WRC
local manifest = {
    appid = 1849250,
    name = "EA SPORTS™ WRC",
    status = "Custom Autopilot Build"
}
return manifest

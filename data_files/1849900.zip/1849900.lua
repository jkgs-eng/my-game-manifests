-- Auto-Generated Blueprint for Among Us 3D: VR
local manifest = {
    appid = 1849900,
    name = "Among Us 3D: VR",
    status = "Custom Autopilot Build"
}
return manifest

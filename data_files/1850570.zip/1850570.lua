-- Auto-Generated Blueprint for DEATH STRANDING DIRECTOR'S CUT
local manifest = {
    appid = 1850570,
    name = "DEATH STRANDING DIRECTOR'S CUT",
    status = "Custom Autopilot Build"
}
return manifest

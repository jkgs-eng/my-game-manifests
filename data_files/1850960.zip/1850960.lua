-- Auto-Generated Blueprint for The Jackbox Party Pack 9
local manifest = {
    appid = 1850960,
    name = "The Jackbox Party Pack 9",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for DAVE THE DIVER
local manifest = {
    appid = 1868140,
    name = "DAVE THE DIVER",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Life is Strange: Double Exposure
local manifest = {
    appid = 1874000,
    name = "Life is Strange: Double Exposure",
    status = "Custom Autopilot Build"
}
return manifest

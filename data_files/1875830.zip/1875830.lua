-- Auto-Generated Blueprint for Shin Megami Tensei V: Vengeance
local manifest = {
    appid = 1875830,
    name = "Shin Megami Tensei V: Vengeance",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Monster Hunter Rise: Sunbreak
local manifest = {
    appid = 1880360,
    name = "Monster Hunter Rise: Sunbreak",
    status = "Custom Autopilot Build"
}
return manifest

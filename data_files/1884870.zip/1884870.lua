-- Auto-Generated Blueprint for The Wolf Among Us 2
local manifest = {
    appid = 1884870,
    name = "The Wolf Among Us 2",
    status = "Custom Autopilot Build"
}
return manifest

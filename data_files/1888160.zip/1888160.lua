-- Auto-Generated Blueprint for ARMORED CORE™ VI FIRES OF RUBICON™
local manifest = {
    appid = 1888160,
    name = "ARMORED CORE™ VI FIRES OF RUBICON™",
    status = "Custom Autopilot Build"
}
return manifest

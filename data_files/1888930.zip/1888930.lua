-- Auto-Generated Blueprint for The Last of Us™ Part I
local manifest = {
    appid = 1888930,
    name = "The Last of Us™ Part I",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Army of Ruin
local manifest = {
    appid = 1918040,
    name = "Army of Ruin",
    status = "Custom Autopilot Build"
}
return manifest

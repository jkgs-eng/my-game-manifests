-- Auto-Generated Blueprint for Demonologist
local manifest = {
    appid = 1929610,
    name = "Demonologist",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for WILD HEARTS™
local manifest = {
    appid = 1938010,
    name = "WILD HEARTS™",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Past Synergy
local manifest = {
    appid = 1939270,
    name = "Past Synergy",
    status = "Custom Autopilot Build"
}
return manifest

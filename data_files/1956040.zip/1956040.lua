-- Auto-Generated Blueprint for Kingdom Eighties
local manifest = {
    appid = 1956040,
    name = "Kingdom Eighties",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Lethal Company
local manifest = {
    appid = 1966720,
    name = "Lethal Company",
    status = "Custom Autopilot Build"
}
return manifest

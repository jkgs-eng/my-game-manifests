-- Auto-Generated Blueprint for 20 Minutes Till Dawn
local manifest = {
    appid = 1966900,
    name = "20 Minutes Till Dawn",
    status = "Custom Autopilot Build"
}
return manifest

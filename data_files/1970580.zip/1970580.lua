-- Auto-Generated Blueprint for Backpack Hero
local manifest = {
    appid = 1970580,
    name = "Backpack Hero",
    status = "Custom Autopilot Build"
}
return manifest

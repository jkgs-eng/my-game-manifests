-- Auto-Generated Blueprint for OCTOPATH TRAVELER II
local manifest = {
    appid = 1971650,
    name = "OCTOPATH TRAVELER II",
    status = "Custom Autopilot Build"
}
return manifest

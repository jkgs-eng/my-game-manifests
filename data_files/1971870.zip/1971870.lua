-- Auto-Generated Blueprint for Mortal Kombat 1
local manifest = {
    appid = 1971870,
    name = "Mortal Kombat 1",
    status = "Custom Autopilot Build"
}
return manifest

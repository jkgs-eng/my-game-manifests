-- Auto-Generated Blueprint for Batman: Arkham City - Game of the Year Edition
local manifest = {
    appid = 200260,
    name = "Batman: Arkham City - Game of the Year Edition",
    status = "Custom Autopilot Build"
}
return manifest

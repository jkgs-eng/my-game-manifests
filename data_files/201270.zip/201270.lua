-- Auto-Generated Blueprint for Total War: SHOGUN 2
local manifest = {
    appid = 201270,
    name = "Total War: SHOGUN 2",
    status = "Custom Autopilot Build"
}
return manifest

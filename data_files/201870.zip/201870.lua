-- Auto-Generated Blueprint for Assassin's Creed® Revelations
local manifest = {
    appid = 201870,
    name = "Assassin's Creed® Revelations",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Alan Wake's American Nightmare
local manifest = {
    appid = 202750,
    name = "Alan Wake's American Nightmare",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Max Payne 3
local manifest = {
    appid = 204100,
    name = "Max Payne 3",
    status = "Custom Autopilot Build"
}
return manifest

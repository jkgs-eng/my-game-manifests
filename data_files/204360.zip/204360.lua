-- Auto-Generated Blueprint for Castle Crashers®
local manifest = {
    appid = 204360,
    name = "Castle Crashers®",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Sins of a Solar Empire®: Rebellion
local manifest = {
    appid = 204880,
    name = "Sins of a Solar Empire®: Rebellion",
    status = "Custom Autopilot Build"
}
return manifest

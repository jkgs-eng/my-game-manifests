-- Auto-Generated Blueprint for Resident Evil 4
local manifest = {
    appid = 2050650,
    name = "Resident Evil 4",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Dishonored
local manifest = {
    appid = 205100,
    name = "Dishonored",
    status = "Custom Autopilot Build"
}
return manifest

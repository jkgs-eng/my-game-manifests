-- Auto-Generated Blueprint for Dragon's Dogma 2
local manifest = {
    appid = 2054970,
    name = "Dragon's Dogma 2",
    status = "Custom Autopilot Build"
}
return manifest

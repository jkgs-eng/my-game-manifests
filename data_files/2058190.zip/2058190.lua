-- Auto-Generated Blueprint for Lost Judgment
local manifest = {
    appid = 2058190,
    name = "Lost Judgment",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Soulstone Survivors
local manifest = {
    appid = 2066020,
    name = "Soulstone Survivors",
    status = "Custom Autopilot Build"
}
return manifest

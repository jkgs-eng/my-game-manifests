-- Auto-Generated Blueprint for High On Life 2
local manifest = {
    appid = 2069250,
    name = "High On Life 2",
    status = "Custom Autopilot Build"
}
return manifest

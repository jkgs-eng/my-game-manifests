-- Auto-Generated Blueprint for SpeedRunners
local manifest = {
    appid = 207140,
    name = "SpeedRunners",
    status = "Custom Autopilot Build"
}
return manifest

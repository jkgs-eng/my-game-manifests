-- Auto-Generated Blueprint for Like a Dragon: Infinite Wealth
local manifest = {
    appid = 2072450,
    name = "Like a Dragon: Infinite Wealth",
    status = "Custom Autopilot Build"
}
return manifest

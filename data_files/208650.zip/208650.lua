-- Auto-Generated Blueprint for Batman™: Arkham Knight
local manifest = {
    appid = 208650,
    name = "Batman™: Arkham Knight",
    status = "Custom Autopilot Build"
}
return manifest

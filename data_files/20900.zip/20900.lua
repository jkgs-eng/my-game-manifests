-- Auto-Generated Blueprint for The Witcher: Enhanced Edition Director's Cut
local manifest = {
    appid = 20900,
    name = "The Witcher: Enhanced Edition Director's Cut",
    status = "Custom Autopilot Build"
}
return manifest

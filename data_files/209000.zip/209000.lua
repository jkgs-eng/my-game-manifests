-- Auto-Generated Blueprint for Batman™: Arkham Origins
local manifest = {
    appid = 209000,
    name = "Batman™: Arkham Origins",
    status = "Custom Autopilot Build"
}
return manifest

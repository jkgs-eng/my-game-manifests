-- Auto-Generated Blueprint for The Witcher 2: Assassins of Kings Enhanced Edition
local manifest = {
    appid = 20920,
    name = "The Witcher 2: Assassins of Kings Enhanced Edition",
    status = "Custom Autopilot Build"
}
return manifest

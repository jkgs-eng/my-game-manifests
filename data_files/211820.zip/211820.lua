-- Auto-Generated Blueprint for Starbound
local manifest = {
    appid = 211820,
    name = "Starbound",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Cyberpunk 2077: Phantom Liberty
local manifest = {
    appid = 2138330,
    name = "Cyberpunk 2077: Phantom Liberty",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Ghostrunner 2
local manifest = {
    appid = 2144740,
    name = "Ghostrunner 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Total War: ROME II - Emperor Edition
local manifest = {
    appid = 214950,
    name = "Total War: ROME II - Emperor Edition",
    status = "Custom Autopilot Build"
}
return manifest

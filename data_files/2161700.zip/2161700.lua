-- Auto-Generated Blueprint for Persona 3 Reload
local manifest = {
    appid = 2161700,
    name = "Persona 3 Reload",
    status = "Custom Autopilot Build"
}
return manifest

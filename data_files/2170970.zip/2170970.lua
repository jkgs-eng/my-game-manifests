-- Auto-Generated Blueprint for Call of Duty®: Black Ops 7 or Call of Duty®: Warzone™ Points
local manifest = {
    appid = 2170970,
    type = "appid",
    name = "Call of Duty®: Black Ops 7 or Call of Duty®: Warzone™ Points",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Worms Armageddon
local manifest = {
    appid = 217200,
    name = "Worms Armageddon",
    status = "Custom Autopilot Build"
}
return manifest

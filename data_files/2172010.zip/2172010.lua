-- Auto-Generated Blueprint for Until Dawn™
local manifest = {
    appid = 2172010,
    name = "Until Dawn™",
    status = "Custom Autopilot Build"
}
return manifest

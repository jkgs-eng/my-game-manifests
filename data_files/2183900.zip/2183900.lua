-- Auto-Generated Blueprint for Warhammer 40,000: Space Marine 2
local manifest = {
    appid = 2183900,
    name = "Warhammer 40,000: Space Marine 2",
    status = "Custom Autopilot Build"
}
return manifest

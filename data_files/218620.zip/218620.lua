-- Auto-Generated Blueprint for PAYDAY 2
local manifest = {
    appid = 218620,
    name = "PAYDAY 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Hotline Miami
local manifest = {
    appid = 219150,
    name = "Hotline Miami",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Chivalry: Medieval Warfare
local manifest = {
    appid = 219640,
    name = "Chivalry: Medieval Warfare",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Don't Starve
local manifest = {
    appid = 219740,
    name = "Don't Starve",
    status = "Custom Autopilot Build"
}
return manifest

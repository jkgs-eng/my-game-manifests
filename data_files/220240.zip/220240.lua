-- Auto-Generated Blueprint for Far Cry 3
local manifest = {
    appid = 220240,
    name = "Far Cry 3",
    status = "Custom Autopilot Build"
}
return manifest

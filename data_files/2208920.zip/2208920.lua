-- Auto-Generated Blueprint for Assassin's Creed Valhalla
local manifest = {
    appid = 2208920,
    name = "Assassin's Creed Valhalla",
    status = "Custom Autopilot Build"
}
return manifest

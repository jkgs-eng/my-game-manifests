-- Auto-Generated Blueprint for DayZ
local manifest = {
    appid = 221100,
    name = "DayZ",
    status = "Custom Autopilot Build"
}
return manifest

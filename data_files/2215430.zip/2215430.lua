-- Auto-Generated Blueprint for Ghost of Tsushima DIRECTOR'S CUT
local manifest = {
    appid = 2215430,
    name = "Ghost of Tsushima DIRECTOR'S CUT",
    status = "Custom Autopilot Build"
}
return manifest

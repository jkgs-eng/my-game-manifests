-- Auto-Generated Blueprint for The Jackbox Party Pack 10
local manifest = {
    appid = 2216830,
    name = "The Jackbox Party Pack 10",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Halls of Torment
local manifest = {
    appid = 2218750,
    name = "Halls of Torment",
    status = "Custom Autopilot Build"
}
return manifest

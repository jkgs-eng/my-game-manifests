-- Auto-Generated Blueprint for Trackmania
local manifest = {
    appid = 2225070,
    name = "Trackmania",
    status = "Custom Autopilot Build"
}
return manifest

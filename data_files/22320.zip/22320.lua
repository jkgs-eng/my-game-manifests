-- Auto-Generated Blueprint for The Elder Scrolls III: Morrowind® Game of the Year Edition
local manifest = {
    appid = 22320,
    name = "The Elder Scrolls III: Morrowind® Game of the Year Edition",
    status = "Custom Autopilot Build"
}
return manifest

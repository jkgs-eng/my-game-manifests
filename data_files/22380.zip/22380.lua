-- Auto-Generated Blueprint for Fallout: New Vegas
local manifest = {
    appid = 22380,
    name = "Fallout: New Vegas",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Persona 5 Tactica
local manifest = {
    appid = 2254740,
    name = "Persona 5 Tactica",
    status = "Custom Autopilot Build"
}
return manifest

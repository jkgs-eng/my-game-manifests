-- Auto-Generated Blueprint for Just Cause™ 3
local manifest = {
    appid = 225540,
    name = "Just Cause™ 3",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Sven Co-op
local manifest = {
    appid = 225840,
    name = "Sven Co-op",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Euro Truck Simulator 2
local manifest = {
    appid = 227300,
    name = "Euro Truck Simulator 2",
    status = "Custom Autopilot Build"
}
return manifest

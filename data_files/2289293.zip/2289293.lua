-- Auto-Generated Blueprint for Call of Duty®: Black Ops Cold War - Gilded Age III: Pro Pack
local manifest = {
    appid = 2289293,
    type = "appid",
    name = "Call of Duty®: Black Ops Cold War - Gilded Age III: Pro Pack",
    status = "Custom Autopilot Build"
}
return manifest

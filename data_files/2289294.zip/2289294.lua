-- Auto-Generated Blueprint for Call of Duty®: Black Ops Cold War - Special Ops Pro Pack
local manifest = {
    appid = 2289294,
    type = "appid",
    name = "Call of Duty®: Black Ops Cold War - Special Ops Pro Pack",
    status = "Custom Autopilot Build"
}
return manifest

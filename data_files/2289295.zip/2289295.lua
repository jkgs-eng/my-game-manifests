-- Auto-Generated Blueprint for Call of Duty®: Black Ops Cold War - Elite Pack
local manifest = {
    appid = 2289295,
    type = "appid",
    name = "Call of Duty®: Black Ops Cold War - Elite Pack",
    status = "Custom Autopilot Build"
}
return manifest

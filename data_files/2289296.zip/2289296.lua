-- Auto-Generated Blueprint for Call of Duty®: Black Ops Cold War - Chemical Reaction: Pro Pack
local manifest = {
    appid = 2289296,
    type = "appid",
    name = "Call of Duty®: Black Ops Cold War - Chemical Reaction: Pro Pack",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Call of Duty®: Black Ops Cold War - Containment Breach: Pro Pack
local manifest = {
    appid = 2289297,
    type = "appid",
    name = "Call of Duty®: Black Ops Cold War - Containment Breach: Pro Pack",
    status = "Custom Autopilot Build"
}
return manifest

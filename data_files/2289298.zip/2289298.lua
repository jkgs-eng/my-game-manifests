-- Auto-Generated Blueprint for Call of Duty®: Black Ops Cold War - Ultimate Pack
local manifest = {
    appid = 2289298,
    type = "appid",
    name = "Call of Duty®: Black Ops Cold War - Ultimate Pack",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Riders Republic
local manifest = {
    appid = 2290180,
    name = "Riders Republic",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for We Were Here Expeditions: The FriendShip
local manifest = {
    appid = 2296990,
    name = "We Were Here Expeditions: The FriendShip",
    status = "Custom Autopilot Build"
}
return manifest

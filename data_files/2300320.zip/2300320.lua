-- Auto-Generated Blueprint for Farming Simulator 25
local manifest = {
    appid = 2300320,
    name = "Farming Simulator 25",
    status = "Custom Autopilot Build"
}
return manifest

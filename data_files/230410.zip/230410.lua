-- Auto-Generated Blueprint for Warframe
local manifest = {
    appid = 230410,
    name = "Warframe",
    status = "Custom Autopilot Build"
}
return manifest

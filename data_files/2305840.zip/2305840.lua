-- Auto-Generated Blueprint for Cat Quest III
local manifest = {
    appid = 2305840,
    name = "Cat Quest III",
    status = "Custom Autopilot Build"
}
return manifest

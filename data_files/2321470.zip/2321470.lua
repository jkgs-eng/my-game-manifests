-- Auto-Generated Blueprint for Deep Rock Galactic: Survivor
local manifest = {
    appid = 2321470,
    name = "Deep Rock Galactic: Survivor",
    status = "Custom Autopilot Build"
}
return manifest

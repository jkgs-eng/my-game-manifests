-- Auto-Generated Blueprint for God of War Ragnarök
local manifest = {
    appid = 2322010,
    name = "God of War Ragnarök",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Tales of Berseria Remastered
local manifest = {
    appid = 2331020,
    name = "Tales of Berseria Remastered",
    status = "Custom Autopilot Build"
}
return manifest

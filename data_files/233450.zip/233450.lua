-- Auto-Generated Blueprint for Prison Architect
local manifest = {
    appid = 233450,
    name = "Prison Architect",
    status = "Custom Autopilot Build"
}
return manifest

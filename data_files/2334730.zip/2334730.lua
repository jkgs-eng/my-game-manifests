-- Auto-Generated Blueprint for Death Must Die
local manifest = {
    appid = 2334730,
    name = "Death Must Die",
    status = "Custom Autopilot Build"
}
return manifest

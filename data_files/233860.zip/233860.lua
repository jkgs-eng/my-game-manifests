-- Auto-Generated Blueprint for Kenshi
local manifest = {
    appid = 233860,
    name = "Kenshi",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Mad Max
local manifest = {
    appid = 234140,
    name = "Mad Max",
    status = "Custom Autopilot Build"
}
return manifest

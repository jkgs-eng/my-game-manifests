-- Auto-Generated Blueprint for Far Cry® 6
local manifest = {
    appid = 2369390,
    name = "Far Cry® 6",
    status = "Custom Autopilot Build"
}
return manifest

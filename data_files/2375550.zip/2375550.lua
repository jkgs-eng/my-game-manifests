-- Auto-Generated Blueprint for Like a Dragon Gaiden: The Man Who Erased His Name
local manifest = {
    appid = 2375550,
    name = "Like a Dragon Gaiden: The Man Who Erased His Name",
    status = "Custom Autopilot Build"
}
return manifest

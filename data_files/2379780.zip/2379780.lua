-- Auto-Generated Blueprint for Balatro
local manifest = {
    appid = 2379780,
    name = "Balatro",
    status = "Custom Autopilot Build"
}
return manifest

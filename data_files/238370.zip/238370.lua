-- Auto-Generated Blueprint for Magicka 2
local manifest = {
    appid = 238370,
    name = "Magicka 2",
    status = "Custom Autopilot Build"
}
return manifest

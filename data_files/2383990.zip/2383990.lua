-- Auto-Generated Blueprint for Ghostbusters: Spirits Unleashed Ecto Edition
local manifest = {
    appid = 2383990,
    name = "Ghostbusters: Spirits Unleashed Ecto Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for BattleBlock Theater®
local manifest = {
    appid = 238460,
    name = "BattleBlock Theater®",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Dying Light
local manifest = {
    appid = 239140,
    name = "Dying Light",
    status = "Custom Autopilot Build"
}
return manifest

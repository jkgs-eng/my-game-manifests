-- Auto-Generated Blueprint for Game Dev Tycoon
local manifest = {
    appid = 239820,
    name = "Game Dev Tycoon",
    status = "Custom Autopilot Build"
}
return manifest

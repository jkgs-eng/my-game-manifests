-- Auto-Generated Blueprint for Middle-earth™: Shadow of Mordor™
local manifest = {
    appid = 241930,
    name = "Middle-earth™: Shadow of Mordor™",
    status = "Custom Autopilot Build"
}
return manifest

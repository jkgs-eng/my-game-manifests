-- Auto-Generated Blueprint for Horizon Forbidden West™ Complete Edition
local manifest = {
    appid = 2420110,
    name = "Horizon Forbidden West™ Complete Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Assassin’s Creed® IV Black Flag™
local manifest = {
    appid = 242050,
    name = "Assassin’s Creed® IV Black Flag™",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Sim Racing Telemetry - F1 23
local manifest = {
    appid = 2426210,
    name = "Sim Racing Telemetry - F1 23",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for S.T.A.L.K.E.R.: Clear Sky - Enhanced Edition
local manifest = {
    appid = 2427420,
    name = "S.T.A.L.K.E.R.: Clear Sky - Enhanced Edition",
    status = "Custom Autopilot Build"
}
return manifest

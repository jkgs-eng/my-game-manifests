-- Auto-Generated Blueprint for The Forest
local manifest = {
    appid = 242760,
    name = "The Forest",
    status = "Custom Autopilot Build"
}
return manifest

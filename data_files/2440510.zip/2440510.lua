-- Auto-Generated Blueprint for Forza Motorsport
local manifest = {
    appid = 2440510,
    name = "Forza Motorsport",
    status = "Custom Autopilot Build"
}
return manifest

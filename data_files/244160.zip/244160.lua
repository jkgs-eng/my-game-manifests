-- Auto-Generated Blueprint for Homeworld Remastered Collection
local manifest = {
    appid = 244160,
    name = "Homeworld Remastered Collection",
    status = "Custom Autopilot Build"
}
return manifest

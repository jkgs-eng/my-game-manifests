-- Auto-Generated Blueprint for Assetto Corsa
local manifest = {
    appid = 244210,
    name = "Assetto Corsa",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Trials Fusion™
local manifest = {
    appid = 245490,
    name = "Trials Fusion™",
    status = "Custom Autopilot Build"
}
return manifest

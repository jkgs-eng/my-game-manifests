-- Auto-Generated Blueprint for Expeditions: A MudRunner Game
local manifest = {
    appid = 2477340,
    name = "Expeditions: A MudRunner Game",
    status = "Custom Autopilot Build"
}
return manifest

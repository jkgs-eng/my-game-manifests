-- Auto-Generated Blueprint for Forza Horizon 6
local manifest = {
    appid = 2483190,
    name = "Forza Horizon 6",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for F1® 24
local manifest = {
    appid = 2488620,
    name = "F1® 24",
    status = "Custom Autopilot Build"
}
return manifest

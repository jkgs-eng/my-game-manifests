-- Auto-Generated Blueprint for FORCED: Slightly Better Edition
local manifest = {
    appid = 249990,
    name = "FORCED: Slightly Better Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Wolf Among Us
local manifest = {
    appid = 250320,
    name = "The Wolf Among Us",
    status = "Custom Autopilot Build"
}
return manifest

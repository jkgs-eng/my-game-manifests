-- Auto-Generated Blueprint for Shovel Knight: Treasure Trove
local manifest = {
    appid = 250760,
    name = "Shovel Knight: Treasure Trove",
    status = "Custom Autopilot Build"
}
return manifest

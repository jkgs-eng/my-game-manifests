-- Auto-Generated Blueprint for The Binding of Isaac: Rebirth
local manifest = {
    appid = 250900,
    name = "The Binding of Isaac: Rebirth",
    status = "Custom Autopilot Build"
}
return manifest

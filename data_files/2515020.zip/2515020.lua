-- Auto-Generated Blueprint for FINAL FANTASY XVI
local manifest = {
    appid = 2515020,
    name = "FINAL FANTASY XVI",
    status = "Custom Autopilot Build"
}
return manifest

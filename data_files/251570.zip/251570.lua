-- Auto-Generated Blueprint for 7 Days to Die
local manifest = {
    appid = 251570,
    name = "7 Days to Die",
    status = "Custom Autopilot Build"
}
return manifest

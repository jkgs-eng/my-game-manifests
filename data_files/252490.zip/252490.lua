-- Auto-Generated Blueprint for Rust
local manifest = {
    appid = 252490,
    name = "Rust",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for KINGDOM HEARTS HD 2.8 Final Chapter Prologue
local manifest = {
    appid = 2552440,
    name = "KINGDOM HEARTS HD 2.8 Final Chapter Prologue",
    status = "Custom Autopilot Build"
}
return manifest

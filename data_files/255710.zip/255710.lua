-- Auto-Generated Blueprint for Cities: Skylines
local manifest = {
    appid = 255710,
    name = "Cities: Skylines",
    status = "Custom Autopilot Build"
}
return manifest

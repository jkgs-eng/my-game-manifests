-- Auto-Generated Blueprint for Gym Simulator 24
local manifest = {
    appid = 2559270,
    name = "Gym Simulator 24",
    status = "Custom Autopilot Build"
}
return manifest

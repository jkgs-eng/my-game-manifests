-- Auto-Generated Blueprint for Chained Together
local manifest = {
    appid = 2567870,
    name = "Chained Together",
    status = "Custom Autopilot Build"
}
return manifest

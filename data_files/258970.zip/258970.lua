-- Auto-Generated Blueprint for Gauntlet™ Slayer Edition
local manifest = {
    appid = 258970,
    name = "Gauntlet™ Slayer Edition",
    status = "Custom Autopilot Build"
}
return manifest

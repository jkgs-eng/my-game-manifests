-- Auto-Generated Blueprint for The Walking Dead: Season Two
local manifest = {
    appid = 261030,
    name = "The Walking Dead: Season Two",
    status = "Custom Autopilot Build"
}
return manifest

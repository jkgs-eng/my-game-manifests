-- Auto-Generated Blueprint for Mount & Blade II: Bannerlord
local manifest = {
    appid = 261550,
    name = "Mount & Blade II: Bannerlord",
    status = "Custom Autopilot Build"
}
return manifest

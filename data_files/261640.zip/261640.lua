-- Auto-Generated Blueprint for Borderlands: The Pre-Sequel
local manifest = {
    appid = 261640,
    name = "Borderlands: The Pre-Sequel",
    status = "Custom Autopilot Build"
}
return manifest

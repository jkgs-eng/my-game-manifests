-- Auto-Generated Blueprint for The Elder Scrolls IV: Oblivion Remastered
local manifest = {
    appid = 2623190,
    name = "The Elder Scrolls IV: Oblivion Remastered",
    status = "Custom Autopilot Build"
}
return manifest

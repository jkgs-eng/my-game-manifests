-- Auto-Generated Blueprint for Life is Strange: Reunion
local manifest = {
    appid = 2624870,
    name = "Life is Strange: Reunion",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for PICO PARK 2
local manifest = {
    appid = 2644470,
    name = "PICO PARK 2",
    status = "Custom Autopilot Build"
}
return manifest

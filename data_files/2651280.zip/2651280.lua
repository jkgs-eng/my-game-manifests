-- Auto-Generated Blueprint for Marvel's Spider-Man 2
local manifest = {
    appid = 2651280,
    name = "Marvel's Spider-Man 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Dead Rising 3 Apocalypse Edition
local manifest = {
    appid = 265550,
    name = "Dead Rising 3 Apocalypse Edition",
    status = "Custom Autopilot Build"
}
return manifest

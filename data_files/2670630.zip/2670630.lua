-- Auto-Generated Blueprint for Supermarket Simulator
local manifest = {
    appid = 2670630,
    name = "Supermarket Simulator",
    status = "Custom Autopilot Build"
}
return manifest

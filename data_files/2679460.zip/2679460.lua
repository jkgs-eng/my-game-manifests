-- Auto-Generated Blueprint for Metaphor: ReFantazio
local manifest = {
    appid = 2679460,
    name = "Metaphor: ReFantazio",
    status = "Custom Autopilot Build"
}
return manifest

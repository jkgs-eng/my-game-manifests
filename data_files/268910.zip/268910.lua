-- Auto-Generated Blueprint for Cuphead
local manifest = {
    appid = 268910,
    name = "Cuphead",
    status = "Custom Autopilot Build"
}
return manifest

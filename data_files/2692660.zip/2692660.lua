-- Auto-Generated Blueprint for Car Mechanic Simulator 2026
local manifest = {
    appid = 2692660,
    name = "Car Mechanic Simulator 2026",
    status = "Autopilot Baseline"
}
return manifest

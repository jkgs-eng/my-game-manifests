-- Auto-Generated Blueprint for The Crew Motorfest
local manifest = {
    appid = 2698940,
    name = "The Crew Motorfest",
    status = "Custom Autopilot Build"
}
return manifest

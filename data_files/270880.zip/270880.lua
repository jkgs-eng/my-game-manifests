-- Auto-Generated Blueprint for American Truck Simulator
local manifest = {
    appid = 270880,
    name = "American Truck Simulator",
    status = "Custom Autopilot Build"
}
return manifest

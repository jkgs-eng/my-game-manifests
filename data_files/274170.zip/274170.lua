-- Auto-Generated Blueprint for Hotline Miami 2: Wrong Number
local manifest = {
    appid = 274170,
    name = "Hotline Miami 2: Wrong Number",
    status = "Custom Autopilot Build"
}
return manifest

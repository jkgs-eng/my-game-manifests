-- Auto-Generated Blueprint for Monster Train 2
local manifest = {
    appid = 2742830,
    name = "Monster Train 2",
    status = "Custom Autopilot Build"
}
return manifest

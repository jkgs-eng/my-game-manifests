-- Auto-Generated Blueprint for Esports Manager 2026
local manifest = {
    appid = 2749950,
    name = "Esports Manager 2026",
    status = "Autopilot Baseline"
}
return manifest

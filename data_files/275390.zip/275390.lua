-- Auto-Generated Blueprint for Guacamelee! Super Turbo Championship Edition
local manifest = {
    appid = 275390,
    name = "Guacamelee! Super Turbo Championship Edition",
    status = "Custom Autopilot Build"
}
return manifest

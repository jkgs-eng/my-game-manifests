-- Auto-Generated Blueprint for No Man's Sky
local manifest = {
    appid = 275850,
    name = "No Man's Sky",
    status = "Custom Autopilot Build"
}
return manifest

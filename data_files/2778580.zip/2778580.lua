-- Auto-Generated Blueprint for ELDEN RING Shadow of the Erdtree
local manifest = {
    appid = 2778580,
    name = "ELDEN RING Shadow of the Erdtree",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Stellaris
local manifest = {
    appid = 281990,
    name = "Stellaris",
    status = "Custom Autopilot Build"
}
return manifest

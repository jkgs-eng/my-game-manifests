-- Auto-Generated Blueprint for BeamNG.drive
local manifest = {
    appid = 284160,
    name = "BeamNG.drive",
    status = "Custom Autopilot Build"
}
return manifest

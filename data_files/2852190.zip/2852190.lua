-- Auto-Generated Blueprint for Monster Hunter Stories 3: Twisted Reflection
local manifest = {
    appid = 2852190,
    name = "Monster Hunter Stories 3: Twisted Reflection",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Gang Beasts
local manifest = {
    appid = 285900,
    name = "Gang Beasts",
    status = "Custom Autopilot Build"
}
return manifest

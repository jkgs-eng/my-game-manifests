-- Auto-Generated Blueprint for Tabletop Simulator
local manifest = {
    appid = 286160,
    name = "Tabletop Simulator",
    status = "Custom Autopilot Build"
}
return manifest

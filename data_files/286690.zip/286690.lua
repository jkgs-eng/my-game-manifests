-- Auto-Generated Blueprint for Metro 2033 Redux
local manifest = {
    appid = 286690,
    name = "Metro 2033 Redux",
    status = "Custom Autopilot Build"
}
return manifest

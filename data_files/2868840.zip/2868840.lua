-- Auto-Generated Blueprint for Slay the Spire 2
local manifest = {
    appid = 2868840,
    name = "Slay the Spire 2",
    status = "Custom Autopilot Build"
}
return manifest

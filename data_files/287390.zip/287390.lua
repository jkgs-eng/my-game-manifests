-- Auto-Generated Blueprint for Metro: Last Light Redux
local manifest = {
    appid = 287390,
    name = "Metro: Last Light Redux",
    status = "Custom Autopilot Build"
}
return manifest

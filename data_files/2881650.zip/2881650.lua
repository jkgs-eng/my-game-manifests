-- Auto-Generated Blueprint for Content Warning
local manifest = {
    appid = 2881650,
    name = "Content Warning",
    status = "Custom Autopilot Build"
}
return manifest

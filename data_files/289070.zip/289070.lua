-- Auto-Generated Blueprint for Sid Meier’s Civilization® VI
local manifest = {
    appid = 289070,
    name = "Sid Meier’s Civilization® VI",
    status = "Custom Autopilot Build"
}
return manifest

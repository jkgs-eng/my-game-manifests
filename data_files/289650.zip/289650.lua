-- Auto-Generated Blueprint for Assassin's Creed® Unity
local manifest = {
    appid = 289650,
    name = "Assassin's Creed® Unity",
    status = "Custom Autopilot Build"
}
return manifest

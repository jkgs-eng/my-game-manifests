-- Auto-Generated Blueprint for LARA CROFT AND THE TEMPLE OF OSIRIS™
local manifest = {
    appid = 289690,
    name = "LARA CROFT AND THE TEMPLE OF OSIRIS™",
    status = "Custom Autopilot Build"
}
return manifest

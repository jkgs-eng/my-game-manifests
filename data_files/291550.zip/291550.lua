-- Auto-Generated Blueprint for Brawlhalla
local manifest = {
    appid = 291550,
    name = "Brawlhalla",
    status = "Custom Autopilot Build"
}
return manifest

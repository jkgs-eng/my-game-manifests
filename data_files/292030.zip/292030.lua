-- Auto-Generated Blueprint for The Witcher 3: Wild Hunt
local manifest = {
    appid = 292030,
    name = "The Witcher 3: Wild Hunt",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for RUINER 2
local manifest = {
    appid = 2936810,
    name = "RUINER 2",
    status = "Custom Autopilot Build"
}
return manifest

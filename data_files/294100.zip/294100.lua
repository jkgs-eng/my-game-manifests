-- Auto-Generated Blueprint for RimWorld
local manifest = {
    appid = 294100,
    name = "RimWorld",
    status = "Custom Autopilot Build"
}
return manifest

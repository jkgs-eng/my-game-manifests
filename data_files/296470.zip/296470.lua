-- Auto-Generated Blueprint for Mount Your Friends
local manifest = {
    appid = 296470,
    name = "Mount Your Friends",
    status = "Custom Autopilot Build"
}
return manifest

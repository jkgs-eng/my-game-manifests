-- Auto-Generated Blueprint for PowerWash Simulator 2
local manifest = {
    appid = 2968420,
    name = "PowerWash Simulator 2",
    status = "Custom Autopilot Build"
}
return manifest

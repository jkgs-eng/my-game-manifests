-- Auto-Generated Blueprint for Solasta II
local manifest = {
    appid = 2975950,
    name = "Solasta II",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Far Cry® 4
local manifest = {
    appid = 298110,
    name = "Far Cry® 4",
    status = "Custom Autopilot Build"
}
return manifest

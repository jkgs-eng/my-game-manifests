-- Auto-Generated Blueprint for Yakuza 0 Director's Cut
local manifest = {
    appid = 2988580,
    name = "Yakuza 0 Director's Cut",
    status = "Custom Autopilot Build"
}
return manifest

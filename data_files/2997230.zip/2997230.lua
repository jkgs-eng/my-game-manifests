-- Auto-Generated Blueprint for Planet of Lana II
local manifest = {
    appid = 2997230,
    name = "Planet of Lana II",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Screencheat
local manifest = {
    appid = 301970,
    name = "Screencheat",
    status = "Custom Autopilot Build"
}
return manifest

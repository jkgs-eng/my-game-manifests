-- Auto-Generated Blueprint for Assassin's Creed Mirage
local manifest = {
    appid = 3035570,
    name = "Assassin's Creed Mirage",
    status = "Custom Autopilot Build"
}
return manifest

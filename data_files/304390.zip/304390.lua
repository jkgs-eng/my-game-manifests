-- Auto-Generated Blueprint for FOR HONOR™
local manifest = {
    appid = 304390,
    name = "FOR HONOR™",
    status = "Custom Autopilot Build"
}
return manifest

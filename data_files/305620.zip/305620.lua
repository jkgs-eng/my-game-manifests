-- Auto-Generated Blueprint for The Long Dark
local manifest = {
    appid = 305620,
    name = "The Long Dark",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for TCG Card Shop Simulator
local manifest = {
    appid = 3070070,
    name = "TCG Card Shop Simulator",
    status = "Custom Autopilot Build"
}
return manifest

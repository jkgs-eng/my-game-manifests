-- Auto-Generated Blueprint for Fantasy Grounds - Cyberpunk RED - Cyberpunk: Edgerunners Mission Kit
local manifest = {
    appid = 3076440,
    name = "Fantasy Grounds - Cyberpunk RED - Cyberpunk: Edgerunners Mission Kit",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Sleeping Dogs: Definitive Edition
local manifest = {
    appid = 307690,
    name = "Sleeping Dogs: Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

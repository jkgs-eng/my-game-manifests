-- Auto-Generated Blueprint for Assassin’s Creed® Rogue
local manifest = {
    appid = 311560,
    name = "Assassin’s Creed® Rogue",
    status = "Custom Autopilot Build"
}
return manifest

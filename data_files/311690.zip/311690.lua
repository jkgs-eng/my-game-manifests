-- Auto-Generated Blueprint for Enter the Gungeon
local manifest = {
    appid = 311690,
    name = "Enter the Gungeon",
    status = "Custom Autopilot Build"
}
return manifest

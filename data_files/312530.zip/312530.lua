-- Auto-Generated Blueprint for Duck Game
local manifest = {
    appid = 312530,
    name = "Duck Game",
    status = "Custom Autopilot Build"
}
return manifest

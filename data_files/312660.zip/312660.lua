-- Auto-Generated Blueprint for Sniper Elite 4
local manifest = {
    appid = 312660,
    name = "Sniper Elite 4",
    status = "Custom Autopilot Build"
}
return manifest

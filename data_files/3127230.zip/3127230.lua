-- Auto-Generated Blueprint for PBA Pro Bowling 2026
local manifest = {
    appid = 3127230,
    name = "PBA Pro Bowling 2026",
    status = "Autopilot Baseline"
}
return manifest

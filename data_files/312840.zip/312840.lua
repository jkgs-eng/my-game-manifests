-- Auto-Generated Blueprint for Fahrenheit: Indigo Prophecy Remastered
local manifest = {
    appid = 312840,
    name = "Fahrenheit: Indigo Prophecy Remastered",
    status = "Custom Autopilot Build"
}
return manifest

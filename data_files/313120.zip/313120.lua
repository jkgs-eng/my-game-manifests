-- Auto-Generated Blueprint for Stranded Deep
local manifest = {
    appid = 313120,
    name = "Stranded Deep",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Trine 3: The Artifacts of Power
local manifest = {
    appid = 319910,
    name = "Trine 3: The Artifacts of Power",
    status = "Custom Autopilot Build"
}
return manifest

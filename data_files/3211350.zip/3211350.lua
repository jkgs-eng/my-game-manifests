-- Auto-Generated Blueprint for Ender Chariot
local manifest = {
    appid = 3211350,
    name = "Ender Chariot",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Don't Starve Together
local manifest = {
    appid = 322330,
    name = "Don't Starve Together",
    status = "Custom Autopilot Build"
}
return manifest

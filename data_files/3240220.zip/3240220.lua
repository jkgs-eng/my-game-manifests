-- Auto-Generated Blueprint for Grand Theft Auto V Enhanced
local manifest = {
    appid = 3240220,
    name = "Grand Theft Auto V Enhanced",
    status = "Custom Autopilot Build"
}
return manifest

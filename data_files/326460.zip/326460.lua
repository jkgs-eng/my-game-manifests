-- Auto-Generated Blueprint for ShellShock Live
local manifest = {
    appid = 326460,
    name = "ShellShock Live",
    status = "Custom Autopilot Build"
}
return manifest

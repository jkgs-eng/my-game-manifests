-- Auto-Generated Blueprint for Worms W.M.D
local manifest = {
    appid = 327030,
    name = "Worms W.M.D",
    status = "Custom Autopilot Build"
}
return manifest

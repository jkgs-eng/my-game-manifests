-- Auto-Generated Blueprint for Beat Saber - Monstercat Mixtape 2 - Alan Walker - "Wake Up"
local manifest = {
    appid = 3274290,
    name = "Beat Saber - Monstercat Mixtape 2 - Alan Walker - "Wake Up"",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Styx: Blades of Greed
local manifest = {
    appid = 3290690,
    name = "Styx: Blades of Greed",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for State of Decay: YOSE
local manifest = {
    appid = 329430,
    name = "State of Decay: YOSE",
    status = "Custom Autopilot Build"
}
return manifest

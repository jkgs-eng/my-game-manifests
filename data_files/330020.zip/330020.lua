-- Auto-Generated Blueprint for Children of Morta
local manifest = {
    appid = 330020,
    name = "Children of Morta",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Tales from the Borderlands
local manifest = {
    appid = 330830,
    name = "Tales from the Borderlands",
    status = "Custom Autopilot Build"
}
return manifest

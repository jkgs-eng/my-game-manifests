-- Auto-Generated Blueprint for The Legend of Heroes: Trails beyond the Horizon
local manifest = {
    appid = 3316940,
    name = "The Legend of Heroes: Trails beyond the Horizon",
    status = "Custom Autopilot Build"
}
return manifest

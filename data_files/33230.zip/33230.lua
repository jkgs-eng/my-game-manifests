-- Auto-Generated Blueprint for Assassin's Creed 2
local manifest = {
    appid = 33230,
    name = "Assassin's Creed 2",
    status = "Custom Autopilot Build"
}
return manifest

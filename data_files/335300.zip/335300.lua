-- Auto-Generated Blueprint for DARK SOULS™ II: Scholar of the First Sin
local manifest = {
    appid = 335300,
    name = "DARK SOULS™ II: Scholar of the First Sin",
    status = "Custom Autopilot Build"
}
return manifest

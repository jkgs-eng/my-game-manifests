-- Auto-Generated Blueprint for Keep Talking and Nobody Explodes
local manifest = {
    appid = 341800,
    name = "Keep Talking and Nobody Explodes",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for ARK: Survival Evolved
local manifest = {
    appid = 346110,
    name = "ARK: Survival Evolved",
    status = "Custom Autopilot Build"
}
return manifest

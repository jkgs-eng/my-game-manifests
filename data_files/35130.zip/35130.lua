-- Auto-Generated Blueprint for Lara Croft and the Guardian of Light
local manifest = {
    appid = 35130,
    name = "Lara Croft and the Guardian of Light",
    status = "Custom Autopilot Build"
}
return manifest

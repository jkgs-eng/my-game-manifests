-- Auto-Generated Blueprint for Batman: Arkham Asylum Game of the Year Edition
local manifest = {
    appid = 35140,
    name = "Batman: Arkham Asylum Game of the Year Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Sébastien Loeb Rally EVO
local manifest = {
    appid = 355060,
    type = "appid",
    name = "Sébastien Loeb Rally EVO",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Middle-earth™: Shadow of War™
local manifest = {
    appid = 356190,
    name = "Middle-earth™: Shadow of War™",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Trine Enchanted Edition
local manifest = {
    appid = 35700,
    name = "Trine Enchanted Edition",
    status = "Custom Autopilot Build"
}
return manifest

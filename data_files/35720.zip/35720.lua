-- Auto-Generated Blueprint for Trine 2: Complete Story
local manifest = {
    appid = 35720,
    name = "Trine 2: Complete Story",
    status = "Custom Autopilot Build"
}
return manifest

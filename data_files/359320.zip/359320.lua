-- Auto-Generated Blueprint for Elite Dangerous
local manifest = {
    appid = 359320,
    name = "Elite Dangerous",
    status = "Custom Autopilot Build"
}
return manifest

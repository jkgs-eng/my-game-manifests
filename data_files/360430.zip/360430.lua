-- Auto-Generated Blueprint for Mafia III: Definitive Edition
local manifest = {
    appid = 360430,
    name = "Mafia III: Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

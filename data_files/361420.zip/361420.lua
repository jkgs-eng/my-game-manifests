-- Auto-Generated Blueprint for ASTRONEER
local manifest = {
    appid = 361420,
    name = "ASTRONEER",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Software Inc.
local manifest = {
    appid = 362620,
    name = "Software Inc.",
    status = "Custom Autopilot Build"
}
return manifest

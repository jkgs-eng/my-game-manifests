-- Auto-Generated Blueprint for rFactor 2
local manifest = {
    appid = 365960,
    name = "rFactor 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Hollow Knight
local manifest = {
    appid = 367520,
    name = "Hollow Knight",
    status = "Custom Autopilot Build"
}
return manifest

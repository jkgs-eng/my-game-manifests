-- Auto-Generated Blueprint for Kingdom: Classic
local manifest = {
    appid = 368230,
    name = "Kingdom: Classic",
    status = "Custom Autopilot Build"
}
return manifest

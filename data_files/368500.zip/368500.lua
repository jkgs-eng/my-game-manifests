-- Auto-Generated Blueprint for Assassin's Creed® Syndicate
local manifest = {
    appid = 368500,
    name = "Assassin's Creed® Syndicate",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Aegis Defenders
local manifest = {
    appid = 371140,
    name = "Aegis Defenders",
    status = "Custom Autopilot Build"
}
return manifest

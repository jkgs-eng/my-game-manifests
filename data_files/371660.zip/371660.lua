-- Auto-Generated Blueprint for Far Cry® Primal
local manifest = {
    appid = 371660,
    name = "Far Cry® Primal",
    status = "Custom Autopilot Build"
}
return manifest

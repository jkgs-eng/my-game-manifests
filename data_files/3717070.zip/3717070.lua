-- Auto-Generated Blueprint for WWE 2K26
local manifest = {
    appid = 3717070,
    name = "WWE 2K26",
    status = "Custom Autopilot Build"
}
return manifest

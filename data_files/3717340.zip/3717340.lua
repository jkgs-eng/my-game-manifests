-- Auto-Generated Blueprint for Yakuza Kiwami 2
local manifest = {
    appid = 3717340,
    name = "Yakuza Kiwami 2",
    status = "Custom Autopilot Build"
}
return manifest

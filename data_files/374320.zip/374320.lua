-- Auto-Generated Blueprint for DARK SOULS™ III
local manifest = {
    appid = 374320,
    name = "DARK SOULS™ III",
    status = "Custom Autopilot Build"
}
return manifest

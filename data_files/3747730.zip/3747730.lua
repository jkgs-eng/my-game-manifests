-- Auto-Generated Blueprint for Legacy of Kain: Defiance Remastered
local manifest = {
    appid = 3747730,
    name = "Legacy of Kain: Defiance Remastered",
    status = "Custom Autopilot Build"
}
return manifest

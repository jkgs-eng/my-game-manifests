-- Auto-Generated Blueprint for Assassin's Creed Black Flag Resynced
local manifest = {
    appid = 3751950,
    name = "Assassin's Creed Black Flag Resynced",
    status = "Custom Autopilot Build"
}
return manifest

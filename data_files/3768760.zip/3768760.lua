-- Auto-Generated Blueprint for 007 First Light
local manifest = {
    appid = 3768760,
    name = "007 First Light",
    status = "Custom Autopilot Build"
}
return manifest

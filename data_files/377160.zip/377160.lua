-- Auto-Generated Blueprint for Fallout 4
local manifest = {
    appid = 377160,
    name = "Fallout 4",
    status = "Custom Autopilot Build"
}
return manifest

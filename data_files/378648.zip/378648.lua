-- Auto-Generated Blueprint for The Witcher 3: Wild Hunt - Blood and Wine
local manifest = {
    appid = 378648,
    type = "appid",
    name = "The Witcher 3: Wild Hunt - Blood and Wine",
    status = "Custom Autopilot Build"
}
return manifest

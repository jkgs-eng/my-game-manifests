-- Auto-Generated Blueprint for FRONT MISSION 3: Remake
local manifest = {
    appid = 3795900,
    name = "FRONT MISSION 3: Remake",
    status = "Custom Autopilot Build"
}
return manifest

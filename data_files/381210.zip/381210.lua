-- Auto-Generated Blueprint for Dead by Daylight
local manifest = {
    appid = 381210,
    name = "Dead by Daylight",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Dead Island Definitive Edition
local manifest = {
    appid = 383150,
    name = "Dead Island Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

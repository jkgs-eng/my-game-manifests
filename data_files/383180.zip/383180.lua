-- Auto-Generated Blueprint for Dead Island: Riptide Definitive Edition
local manifest = {
    appid = 383180,
    name = "Dead Island: Riptide Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

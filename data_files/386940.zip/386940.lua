-- Auto-Generated Blueprint for Ultimate Chicken Horse
local manifest = {
    appid = 386940,
    name = "Ultimate Chicken Horse",
    status = "Custom Autopilot Build"
}
return manifest

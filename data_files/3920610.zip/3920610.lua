-- Auto-Generated Blueprint for FATAL FRAME II: Crimson Butterfly REMAKE
local manifest = {
    appid = 3920610,
    name = "FATAL FRAME II: Crimson Butterfly REMAKE",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for X4: Foundations
local manifest = {
    appid = 392160,
    name = "X4: Foundations",
    status = "Custom Autopilot Build"
}
return manifest

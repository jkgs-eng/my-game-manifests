-- Auto-Generated Blueprint for Tour de France 2026
local manifest = {
    appid = 3936520,
    name = "Tour de France 2026",
    status = "Autopilot Baseline"
}
return manifest

-- Auto-Generated Blueprint for Hearts of Iron IV
local manifest = {
    appid = 394360,
    name = "Hearts of Iron IV",
    status = "Custom Autopilot Build"
}
return manifest

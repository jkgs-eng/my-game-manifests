-- Auto-Generated Blueprint for HELLDIVERS™ Dive Harder Edition
local manifest = {
    appid = 394510,
    name = "HELLDIVERS™ Dive Harder Edition",
    status = "Custom Autopilot Build"
}
return manifest

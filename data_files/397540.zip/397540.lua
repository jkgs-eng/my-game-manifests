-- Auto-Generated Blueprint for Borderlands 3
local manifest = {
    appid = 397540,
    name = "Borderlands 3",
    status = "Custom Autopilot Build"
}
return manifest

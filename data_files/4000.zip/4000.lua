-- Auto-Generated Blueprint for Garry's Mod
local manifest = {
    appid = 4000,
    name = "Garry's Mod",
    status = "Custom Autopilot Build"
}
return manifest

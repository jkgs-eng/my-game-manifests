-- Auto-Generated Blueprint for Warhammer 40,000: Darktide - Hive Scum Class
local manifest = {
    appid = 4013290,
    name = "Warhammer 40,000: Darktide - Hive Scum Class",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for EA SPORTS™ College Football 27
local manifest = {
    appid = 4032350,
    name = "EA SPORTS™ College Football 27",
    status = "Custom Autopilot Build"
}
return manifest

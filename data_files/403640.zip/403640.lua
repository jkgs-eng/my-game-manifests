-- Auto-Generated Blueprint for Dishonored 2
local manifest = {
    appid = 403640,
    name = "Dishonored 2",
    status = "Custom Autopilot Build"
}
return manifest

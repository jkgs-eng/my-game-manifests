-- Auto-Generated Blueprint for BioShock™ Remastered
local manifest = {
    appid = 409710,
    name = "BioShock™ Remastered",
    status = "Custom Autopilot Build"
}
return manifest

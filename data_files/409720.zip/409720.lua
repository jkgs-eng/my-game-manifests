-- Auto-Generated Blueprint for BioShock™ 2 Remastered
local manifest = {
    appid = 409720,
    name = "BioShock™ 2 Remastered",
    status = "Custom Autopilot Build"
}
return manifest

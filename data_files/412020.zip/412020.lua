-- Auto-Generated Blueprint for Metro Exodus
local manifest = {
    appid = 412020,
    name = "Metro Exodus",
    status = "Custom Autopilot Build"
}
return manifest

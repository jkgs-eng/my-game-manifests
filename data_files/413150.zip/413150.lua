-- Auto-Generated Blueprint for Stardew Valley
local manifest = {
    appid = 413150,
    name = "Stardew Valley",
    status = "Custom Autopilot Build"
}
return manifest

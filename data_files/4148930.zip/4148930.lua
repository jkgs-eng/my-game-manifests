-- Auto-Generated Blueprint for F1® 25: 2026 Season Pack
local manifest = {
    appid = 4148930,
    name = "F1® 25: 2026 Season Pack",
    status = "Autopilot Baseline"
}
return manifest

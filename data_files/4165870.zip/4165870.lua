-- Auto-Generated Blueprint for Steam Controller
local manifest = {
    appid = 4165870,
    name = "Steam Controller",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Spelunky 2
local manifest = {
    appid = 418530,
    name = "Spelunky 2",
    status = "Custom Autopilot Build"
}
return manifest

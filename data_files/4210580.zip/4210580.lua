-- Auto-Generated Blueprint for Ore Factory Squad ⛏️
local manifest = {
    appid = 4210580,
    name = "Ore Factory Squad ⛏️",
    status = "Custom Autopilot Build"
}
return manifest

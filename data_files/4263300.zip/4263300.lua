-- Auto-Generated Blueprint for Brawlhalla - Spring Esports 2026 Pack
local manifest = {
    appid = 4263300,
    name = "Brawlhalla - Spring Esports 2026 Pack",
    status = "Autopilot Baseline"
}
return manifest

-- Auto-Generated Blueprint for Abiotic Factor
local manifest = {
    appid = 427410,
    name = "Abiotic Factor",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Factorio
local manifest = {
    appid = 427520,
    name = "Factorio",
    status = "Custom Autopilot Build"
}
return manifest

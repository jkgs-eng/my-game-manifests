-- Auto-Generated Blueprint for Youtubers Life
local manifest = {
    appid = 428690,
    name = "Youtubers Life",
    status = "Custom Autopilot Build"
}
return manifest

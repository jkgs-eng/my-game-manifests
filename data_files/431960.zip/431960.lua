-- Auto-Generated Blueprint for Wallpaper Engine
local manifest = {
    appid = 431960,
    name = "Wallpaper Engine",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Substance 3D Painter 2026
local manifest = {
    appid = 4329260,
    name = "Substance 3D Painter 2026",
    status = "Autopilot Baseline"
}
return manifest

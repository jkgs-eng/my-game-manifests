-- Auto-Generated Blueprint for Substance 3D Designer 2026
local manifest = {
    appid = 4329280,
    name = "Substance 3D Designer 2026",
    status = "Autopilot Baseline"
}
return manifest

-- Auto-Generated Blueprint for The Jackbox Party Pack 3
local manifest = {
    appid = 434170,
    name = "The Jackbox Party Pack 3",
    status = "Custom Autopilot Build"
}
return manifest

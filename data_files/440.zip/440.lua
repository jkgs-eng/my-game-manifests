-- Auto-Generated Blueprint for Team Fortress 2
local manifest = {
    appid = 440,
    name = "Team Fortress 2",
    status = "Custom Autopilot Build"
}
return manifest

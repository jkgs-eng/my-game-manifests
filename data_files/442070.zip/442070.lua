-- Auto-Generated Blueprint for Drawful 2
local manifest = {
    appid = 442070,
    name = "Drawful 2",
    status = "Custom Autopilot Build"
}
return manifest

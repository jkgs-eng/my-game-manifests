-- Auto-Generated Blueprint for Warframe: TennoCon 2026 Digital Pack
local manifest = {
    appid = 4447660,
    name = "Warframe: TennoCon 2026 Digital Pack",
    status = "Autopilot Baseline"
}
return manifest

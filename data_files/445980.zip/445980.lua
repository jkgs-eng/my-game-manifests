-- Auto-Generated Blueprint for Wizard of Legend
local manifest = {
    appid = 445980,
    name = "Wizard of Legend",
    status = "Custom Autopilot Build"
}
return manifest

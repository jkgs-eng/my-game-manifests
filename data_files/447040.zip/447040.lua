-- Auto-Generated Blueprint for Watch_Dogs® 2
local manifest = {
    appid = 447040,
    name = "Watch_Dogs® 2",
    status = "Custom Autopilot Build"
}
return manifest

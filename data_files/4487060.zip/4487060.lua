-- Auto-Generated Blueprint for Northgard Battlegrounds
local manifest = {
    appid = 4487060,
    name = "Northgard Battlegrounds",
    status = "Custom Autopilot Build"
}
return manifest

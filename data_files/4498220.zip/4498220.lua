-- Auto-Generated Blueprint for Brotato: Primal Dread
local manifest = {
    appid = 4498220,
    name = "Brotato: Primal Dread",
    status = "Custom Autopilot Build"
}
return manifest

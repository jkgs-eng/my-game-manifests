-- Auto-Generated Blueprint for Oxygen Not Included
local manifest = {
    appid = 457140,
    name = "Oxygen Not Included",
    status = "Custom Autopilot Build"
}
return manifest

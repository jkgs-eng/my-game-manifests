-- Auto-Generated Blueprint for Dead Rising® 2
local manifest = {
    appid = 45740,
    name = "Dead Rising® 2",
    status = "Custom Autopilot Build"
}
return manifest

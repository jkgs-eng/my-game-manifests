-- Auto-Generated Blueprint for Steep™
local manifest = {
    appid = 460920,
    name = "Steep™",
    status = "Custom Autopilot Build"
}
return manifest

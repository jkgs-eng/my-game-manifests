-- Auto-Generated Blueprint for Katana ZERO
local manifest = {
    appid = 460950,
    name = "Katana ZERO",
    status = "Custom Autopilot Build"
}
return manifest

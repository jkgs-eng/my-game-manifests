-- Auto-Generated Blueprint for Forza Horizon 6 1998 Nissan Skyline GT-R 40th Anniversary
local manifest = {
    appid = 4610350,
    name = "Forza Horizon 6 1998 Nissan Skyline GT-R 40th Anniversary",
    status = "Custom Autopilot Build"
}
return manifest

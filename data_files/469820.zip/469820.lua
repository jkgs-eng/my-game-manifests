-- Auto-Generated Blueprint for Genital Jousting
local manifest = {
    appid = 469820,
    name = "Genital Jousting",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Total War: MEDIEVAL II – Definitive Edition
local manifest = {
    appid = 4700,
    name = "Total War: MEDIEVAL II – Definitive Edition",
    status = "Custom Autopilot Build"
}
return manifest

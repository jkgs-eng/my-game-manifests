-- Auto-Generated Blueprint for UNO
local manifest = {
    appid = 470220,
    name = "UNO",
    status = "Custom Autopilot Build"
}
return manifest

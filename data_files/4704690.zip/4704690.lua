-- Auto-Generated Blueprint for MECCHA CHAMELEON
local manifest = {
    appid = 4704690,
    name = "MECCHA CHAMELEON",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Nine Parchments
local manifest = {
    appid = 471550,
    name = "Nine Parchments",
    status = "Custom Autopilot Build"
}
return manifest

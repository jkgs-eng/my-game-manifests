-- Auto-Generated Blueprint for Quantum Break
local manifest = {
    appid = 474960,
    name = "Quantum Break",
    status = "Custom Autopilot Build"
}
return manifest

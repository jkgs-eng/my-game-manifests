-- Auto-Generated Blueprint for Human Fall Flat
local manifest = {
    appid = 477160,
    name = "Human Fall Flat",
    status = "Custom Autopilot Build"
}
return manifest

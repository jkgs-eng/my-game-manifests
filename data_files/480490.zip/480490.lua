-- Auto-Generated Blueprint for Prey
local manifest = {
    appid = 480490,
    name = "Prey",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Assassin’s Creed® Brotherhood
local manifest = {
    appid = 48190,
    name = "Assassin’s Creed® Brotherhood",
    status = "Custom Autopilot Build"
}
return manifest

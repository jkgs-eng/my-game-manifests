-- Auto-Generated Blueprint for Nioh: Complete Edition
local manifest = {
    appid = 485510,
    name = "Nioh: Complete Edition",
    status = "Custom Autopilot Build"
}
return manifest

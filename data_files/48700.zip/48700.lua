-- Auto-Generated Blueprint for Mount & Blade: Warband
local manifest = {
    appid = 48700,
    name = "Mount & Blade: Warband",
    status = "Custom Autopilot Build"
}
return manifest

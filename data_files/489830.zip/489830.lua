-- Auto-Generated Blueprint for The Elder Scrolls V: Skyrim Special Edition
local manifest = {
    appid = 489830,
    name = "The Elder Scrolls V: Skyrim Special Edition",
    status = "Custom Autopilot Build"
}
return manifest

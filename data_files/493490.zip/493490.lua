-- Auto-Generated Blueprint for City Car Driving
local manifest = {
    appid = 493490,
    name = "City Car Driving",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for GTFO
local manifest = {
    appid = 493520,
    name = "GTFO",
    status = "Custom Autopilot Build"
}
return manifest

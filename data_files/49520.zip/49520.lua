-- Auto-Generated Blueprint for Borderlands 2
local manifest = {
    appid = 49520,
    name = "Borderlands 2",
    status = "Custom Autopilot Build"
}
return manifest

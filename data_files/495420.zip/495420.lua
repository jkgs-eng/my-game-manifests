-- Auto-Generated Blueprint for State of Decay 2: Juggernaut Edition
local manifest = {
    appid = 495420,
    name = "State of Decay 2: Juggernaut Edition",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Kingdom: New Lands
local manifest = {
    appid = 496300,
    name = "Kingdom: New Lands",
    status = "Custom Autopilot Build"
}
return manifest

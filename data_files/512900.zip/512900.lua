-- Auto-Generated Blueprint for Streets of Rogue
local manifest = {
    appid = 512900,
    name = "Streets of Rogue",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for My Summer Car
local manifest = {
    appid = 516750,
    name = "My Summer Car",
    status = "Custom Autopilot Build"
}
return manifest

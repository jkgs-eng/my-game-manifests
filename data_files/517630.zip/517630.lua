-- Auto-Generated Blueprint for Just Cause 4 Reloaded
local manifest = {
    appid = 517630,
    name = "Just Cause 4 Reloaded",
    status = "Custom Autopilot Build"
}
return manifest

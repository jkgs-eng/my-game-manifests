-- Auto-Generated Blueprint for Use Your Words
local manifest = {
    appid = 521350,
    name = "Use Your Words",
    status = "Custom Autopilot Build"
}
return manifest

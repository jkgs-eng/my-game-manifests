-- Auto-Generated Blueprint for Satisfactory
local manifest = {
    appid = 526870,
    name = "Satisfactory",
    status = "Custom Autopilot Build"
}
return manifest

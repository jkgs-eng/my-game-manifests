-- Auto-Generated Blueprint for Life is Strange 2
local manifest = {
    appid = 532210,
    name = "Life is Strange 2",
    status = "Custom Autopilot Build"
}
return manifest

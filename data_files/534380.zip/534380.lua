-- Auto-Generated Blueprint for Dying Light 2 Stay Human: Reloaded Edition
local manifest = {
    appid = 534380,
    name = "Dying Light 2 Stay Human: Reloaded Edition",
    status = "Custom Autopilot Build"
}
return manifest

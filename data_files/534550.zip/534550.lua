-- Auto-Generated Blueprint for Guacamelee! 2
local manifest = {
    appid = 534550,
    name = "Guacamelee! 2",
    status = "Custom Autopilot Build"
}
return manifest

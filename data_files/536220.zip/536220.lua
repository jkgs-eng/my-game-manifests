-- Auto-Generated Blueprint for The Walking Dead: A New Frontier
local manifest = {
    appid = 536220,
    name = "The Walking Dead: A New Frontier",
    status = "Custom Autopilot Build"
}
return manifest

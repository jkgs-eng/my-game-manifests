-- Auto-Generated Blueprint for Ancestors: The Humankind Odyssey
local manifest = {
    appid = 536270,
    name = "Ancestors: The Humankind Odyssey",
    status = "Custom Autopilot Build"
}
return manifest

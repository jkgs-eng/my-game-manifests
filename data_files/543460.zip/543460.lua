-- Auto-Generated Blueprint for Dead Rising 4
local manifest = {
    appid = 543460,
    name = "Dead Rising 4",
    status = "Custom Autopilot Build"
}
return manifest

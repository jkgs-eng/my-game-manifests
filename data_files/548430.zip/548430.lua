-- Auto-Generated Blueprint for Deep Rock Galactic
local manifest = {
    appid = 548430,
    name = "Deep Rock Galactic",
    status = "Custom Autopilot Build"
}
return manifest

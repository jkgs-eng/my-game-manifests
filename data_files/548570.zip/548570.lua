-- Auto-Generated Blueprint for RAGE 2
local manifest = {
    appid = 548570,
    name = "RAGE 2",
    status = "Custom Autopilot Build"
}
return manifest

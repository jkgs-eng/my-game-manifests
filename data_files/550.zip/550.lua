-- Auto-Generated Blueprint for Left 4 Dead 2
local manifest = {
    appid = 550,
    name = "Left 4 Dead 2",
    status = "Custom Autopilot Build"
}
return manifest

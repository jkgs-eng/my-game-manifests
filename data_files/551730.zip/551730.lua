-- Auto-Generated Blueprint for Toukiden 2
local manifest = {
    appid = 551730,
    name = "Toukiden 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Warhammer: Vermintide 2
local manifest = {
    appid = 552500,
    name = "Warhammer: Vermintide 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Far Cry® 5
local manifest = {
    appid = 552520,
    name = "Far Cry® 5",
    status = "Custom Autopilot Build"
}
return manifest

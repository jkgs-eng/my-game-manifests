-- Auto-Generated Blueprint for Lethal League Blaze
local manifest = {
    appid = 553310,
    name = "Lethal League Blaze",
    status = "Custom Autopilot Build"
}
return manifest

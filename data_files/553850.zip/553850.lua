-- Auto-Generated Blueprint for HELLDIVERS™ 2
local manifest = {
    appid = 553850,
    name = "HELLDIVERS™ 2",
    status = "Custom Autopilot Build"
}
return manifest

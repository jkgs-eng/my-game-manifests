-- Auto-Generated Blueprint for Life is Strange: Before the Storm
local manifest = {
    appid = 554620,
    name = "Life is Strange: Before the Storm",
    status = "Custom Autopilot Build"
}
return manifest

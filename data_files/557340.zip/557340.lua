-- Auto-Generated Blueprint for My Friend Pedro
local manifest = {
    appid = 557340,
    name = "My Friend Pedro",
    status = "Custom Autopilot Build"
}
return manifest

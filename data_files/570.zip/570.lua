-- Auto-Generated Blueprint for Dota 2
local manifest = {
    appid = 570,
    name = "Dota 2",
    status = "Custom Autopilot Build"
}
return manifest

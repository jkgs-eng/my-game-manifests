-- Auto-Generated Blueprint for DARK SOULS™: REMASTERED
local manifest = {
    appid = 570940,
    name = "DARK SOULS™: REMASTERED",
    status = "Custom Autopilot Build"
}
return manifest

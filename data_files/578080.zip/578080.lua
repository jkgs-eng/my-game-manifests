-- Auto-Generated Blueprint for PUBG: BATTLEGROUNDS
local manifest = {
    appid = 578080,
    name = "PUBG: BATTLEGROUNDS",
    status = "Custom Autopilot Build"
}
return manifest

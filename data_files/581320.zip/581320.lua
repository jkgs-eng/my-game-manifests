-- Auto-Generated Blueprint for Insurgency: Sandstorm
local manifest = {
    appid = 581320,
    name = "Insurgency: Sandstorm",
    status = "Custom Autopilot Build"
}
return manifest

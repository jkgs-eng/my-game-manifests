-- Auto-Generated Blueprint for Monster Hunter: World
local manifest = {
    appid = 582010,
    name = "Monster Hunter: World",
    status = "Custom Autopilot Build"
}
return manifest

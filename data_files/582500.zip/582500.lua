-- Auto-Generated Blueprint for We Were Here
local manifest = {
    appid = 582500,
    name = "We Were Here",
    status = "Custom Autopilot Build"
}
return manifest

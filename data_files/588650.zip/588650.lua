-- Auto-Generated Blueprint for Dead Cells
local manifest = {
    appid = 588650,
    name = "Dead Cells",
    status = "Custom Autopilot Build"
}
return manifest

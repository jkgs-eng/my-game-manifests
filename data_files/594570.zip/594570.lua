-- Auto-Generated Blueprint for Total War: WARHAMMER II
local manifest = {
    appid = 594570,
    name = "Total War: WARHAMMER II",
    status = "Custom Autopilot Build"
}
return manifest

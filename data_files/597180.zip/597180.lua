-- Auto-Generated Blueprint for Old World
local manifest = {
    appid = 597180,
    name = "Old World",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Startup Company
local manifest = {
    appid = 606800,
    name = "Startup Company",
    status = "Custom Autopilot Build"
}
return manifest

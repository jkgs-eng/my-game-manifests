-- Auto-Generated Blueprint for The Jackbox Party Pack 4
local manifest = {
    appid = 610180,
    name = "The Jackbox Party Pack 4",
    status = "Custom Autopilot Build"
}
return manifest

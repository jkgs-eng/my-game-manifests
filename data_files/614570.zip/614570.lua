-- Auto-Generated Blueprint for Dishonored®: Death of the Outsider™
local manifest = {
    appid = 614570,
    name = "Dishonored®: Death of the Outsider™",
    status = "Custom Autopilot Build"
}
return manifest

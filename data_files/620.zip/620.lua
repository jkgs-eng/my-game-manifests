-- Auto-Generated Blueprint for Portal 2
local manifest = {
    appid = 620,
    name = "Portal 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for MORDHAU
local manifest = {
    appid = 629760,
    name = "MORDHAU",
    status = "Custom Autopilot Build"
}
return manifest

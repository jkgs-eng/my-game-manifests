-- Auto-Generated Blueprint for Risk of Rain 2
local manifest = {
    appid = 632360,
    name = "Risk of Rain 2",
    status = "Custom Autopilot Build"
}
return manifest

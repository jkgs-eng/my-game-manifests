-- Auto-Generated Blueprint for FINAL FANTASY XV WINDOWS EDITION
local manifest = {
    appid = 637650,
    name = "FINAL FANTASY XV WINDOWS EDITION",
    status = "Custom Autopilot Build"
}
return manifest

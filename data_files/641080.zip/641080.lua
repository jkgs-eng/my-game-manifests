-- Auto-Generated Blueprint for Trials® Rising
local manifest = {
    appid = 641080,
    name = "Trials® Rising",
    status = "Custom Autopilot Build"
}
return manifest

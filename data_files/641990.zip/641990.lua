-- Auto-Generated Blueprint for The Escapists 2
local manifest = {
    appid = 641990,
    name = "The Escapists 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Surge 2
local manifest = {
    appid = 644830,
    name = "The Surge 2",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for They Are Billions
local manifest = {
    appid = 644930,
    name = "They Are Billions",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Car Mechanic Simulator 2018
local manifest = {
    appid = 645630,
    name = "Car Mechanic Simulator 2018",
    status = "Custom Autopilot Build"
}
return manifest

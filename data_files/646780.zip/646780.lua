-- Auto-Generated Blueprint for Jalopy - Soundtrack
local manifest = {
    appid = 646780,
    name = "Jalopy - Soundtrack",
    status = "Custom Autopilot Build"
}
return manifest

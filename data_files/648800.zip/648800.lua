-- Auto-Generated Blueprint for Raft
local manifest = {
    appid = 648800,
    name = "Raft",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Super Bunny Man
local manifest = {
    appid = 673750,
    name = "Super Bunny Man",
    status = "Custom Autopilot Build"
}
return manifest

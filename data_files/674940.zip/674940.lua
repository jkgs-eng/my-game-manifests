-- Auto-Generated Blueprint for Stick Fight: The Game
local manifest = {
    appid = 674940,
    name = "Stick Fight: The Game",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for MudRunner
local manifest = {
    appid = 675010,
    name = "MudRunner",
    status = "Custom Autopilot Build"
}
return manifest

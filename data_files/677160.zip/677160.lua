-- Auto-Generated Blueprint for We Were Here Too
local manifest = {
    appid = 677160,
    name = "We Were Here Too",
    status = "Custom Autopilot Build"
}
return manifest

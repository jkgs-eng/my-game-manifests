-- Auto-Generated Blueprint for Medieval Shopkeeper Simulator
local manifest = {
    appid = 677450,
    name = "Medieval Shopkeeper Simulator",
    status = "Custom Autopilot Build"
}
return manifest

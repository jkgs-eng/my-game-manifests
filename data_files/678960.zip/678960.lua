-- Auto-Generated Blueprint for CODE VEIN
local manifest = {
    appid = 678960,
    name = "CODE VEIN",
    status = "Custom Autopilot Build"
}
return manifest

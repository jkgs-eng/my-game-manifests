-- Auto-Generated Blueprint for Descenders
local manifest = {
    appid = 681280,
    name = "Descenders",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Mewgenics
local manifest = {
    appid = 686060,
    name = "Mewgenics",
    status = "Custom Autopilot Build"
}
return manifest

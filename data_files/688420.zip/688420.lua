-- Auto-Generated Blueprint for Bad North: Jotunn Edition
local manifest = {
    appid = 688420,
    name = "Bad North: Jotunn Edition",
    status = "Custom Autopilot Build"
}
return manifest

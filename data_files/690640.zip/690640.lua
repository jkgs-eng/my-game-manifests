-- Auto-Generated Blueprint for Trine 4: The Nightmare Prince
local manifest = {
    appid = 690640,
    name = "Trine 4: The Nightmare Prince",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for DiRT Rally 2.0
local manifest = {
    appid = 690790,
    name = "DiRT Rally 2.0",
    status = "Custom Autopilot Build"
}
return manifest

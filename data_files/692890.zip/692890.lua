-- Auto-Generated Blueprint for Roboquest
local manifest = {
    appid = 692890,
    name = "Roboquest",
    status = "Custom Autopilot Build"
}
return manifest

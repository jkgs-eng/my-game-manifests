-- Auto-Generated Blueprint for Zombie Army 4: Dead War
local manifest = {
    appid = 694280,
    name = "Zombie Army 4: Dead War",
    status = "Custom Autopilot Build"
}
return manifest

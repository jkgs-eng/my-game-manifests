-- Auto-Generated Blueprint for Kingdom Two Crowns
local manifest = {
    appid = 701160,
    name = "Kingdom Two Crowns",
    status = "Custom Autopilot Build"
}
return manifest

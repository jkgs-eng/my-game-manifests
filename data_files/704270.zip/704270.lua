-- Auto-Generated Blueprint for Generation Zero®
local manifest = {
    appid = 704270,
    name = "Generation Zero®",
    status = "Custom Autopilot Build"
}
return manifest

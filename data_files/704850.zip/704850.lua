-- Auto-Generated Blueprint for Thief Simulator
local manifest = {
    appid = 704850,
    name = "Thief Simulator",
    status = "Custom Autopilot Build"
}
return manifest

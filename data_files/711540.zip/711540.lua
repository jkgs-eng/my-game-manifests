-- Auto-Generated Blueprint for Lonely Mountains: Downhill
local manifest = {
    appid = 711540,
    name = "Lonely Mountains: Downhill",
    status = "Custom Autopilot Build"
}
return manifest

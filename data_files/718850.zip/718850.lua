-- Auto-Generated Blueprint for Age of Wonders: Planetfall
local manifest = {
    appid = 718850,
    name = "Age of Wonders: Planetfall",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Overcooked! 2
local manifest = {
    appid = 728880,
    name = "Overcooked! 2",
    status = "Custom Autopilot Build"
}
return manifest

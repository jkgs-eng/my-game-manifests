-- Auto-Generated Blueprint for Borderlands Game of the Year Enhanced
local manifest = {
    appid = 729040,
    name = "Borderlands Game of the Year Enhanced",
    status = "Custom Autopilot Build"
}
return manifest

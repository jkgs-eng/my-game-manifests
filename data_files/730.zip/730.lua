-- Auto-Generated Blueprint for Counter-Strike 2
local manifest = {
    appid = 730,
    name = "Counter-Strike 2",
    status = "Custom Autopilot Build"
}
return manifest

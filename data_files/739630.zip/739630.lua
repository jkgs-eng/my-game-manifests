-- Auto-Generated Blueprint for Phasmophobia
local manifest = {
    appid = 739630,
    name = "Phasmophobia",
    status = "Custom Autopilot Build"
}
return manifest

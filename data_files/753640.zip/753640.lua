-- Auto-Generated Blueprint for Outer Wilds
local manifest = {
    appid = 753640,
    name = "Outer Wilds",
    status = "Custom Autopilot Build"
}
return manifest

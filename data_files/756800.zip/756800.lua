-- Auto-Generated Blueprint for Contraband Police
local manifest = {
    appid = 756800,
    name = "Contraband Police",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Messenger
local manifest = {
    appid = 764790,
    name = "The Messenger",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Crab Champions
local manifest = {
    appid = 774801,
    name = "Crab Champions",
    status = "Custom Autopilot Build"
}
return manifest

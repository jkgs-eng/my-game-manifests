-- Auto-Generated Blueprint for Total War: THREE KINGDOMS
local manifest = {
    appid = 779340,
    name = "Total War: THREE KINGDOMS",
    status = "Custom Autopilot Build"
}
return manifest

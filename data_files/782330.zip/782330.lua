-- Auto-Generated Blueprint for DOOM Eternal
local manifest = {
    appid = 782330,
    name = "DOOM Eternal",
    status = "Custom Autopilot Build"
}
return manifest

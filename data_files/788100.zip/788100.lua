-- Auto-Generated Blueprint for Neon Abyss
local manifest = {
    appid = 788100,
    name = "Neon Abyss",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Assetto Corsa Competizione
local manifest = {
    appid = 805550,
    name = "Assetto Corsa Competizione",
    status = "Custom Autopilot Build"
}
return manifest

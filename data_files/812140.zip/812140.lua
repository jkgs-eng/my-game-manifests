-- Auto-Generated Blueprint for Assassin's Creed® Odyssey
local manifest = {
    appid = 812140,
    name = "Assassin's Creed® Odyssey",
    status = "Custom Autopilot Build"
}
return manifest

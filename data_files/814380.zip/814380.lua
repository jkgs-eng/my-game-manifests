-- Auto-Generated Blueprint for Sekiro™: Shadows Die Twice - GOTY Edition
local manifest = {
    appid = 814380,
    name = "Sekiro™: Shadows Die Twice - GOTY Edition",
    status = "Custom Autopilot Build"
}
return manifest

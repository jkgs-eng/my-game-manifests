-- Auto-Generated Blueprint for Green Hell
local manifest = {
    appid = 815370,
    name = "Green Hell",
    status = "Custom Autopilot Build"
}
return manifest

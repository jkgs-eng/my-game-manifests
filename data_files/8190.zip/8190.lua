-- Auto-Generated Blueprint for Just Cause 2
local manifest = {
    appid = 8190,
    name = "Just Cause 2",
    status = "Custom Autopilot Build"
}
return manifest

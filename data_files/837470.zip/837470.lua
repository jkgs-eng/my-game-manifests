-- Auto-Generated Blueprint for Untitled Goose Game
local manifest = {
    appid = 837470,
    name = "Untitled Goose Game",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Subnautica: Below Zero
local manifest = {
    appid = 848450,
    name = "Subnautica: Below Zero",
    status = "Custom Autopilot Build"
}
return manifest

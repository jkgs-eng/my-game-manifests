-- Auto-Generated Blueprint for Sim Racing Telemetry - Project Cars 2
local manifest = {
    appid = 860233,
    name = "Sim Racing Telemetry - Project Cars 2",
    status = "Custom Autopilot Build"
}
return manifest

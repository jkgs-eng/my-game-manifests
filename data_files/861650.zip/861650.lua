-- Auto-Generated Blueprint for Session: Skate Sim
local manifest = {
    appid = 861650,
    name = "Session: Skate Sim",
    status = "Custom Autopilot Build"
}
return manifest

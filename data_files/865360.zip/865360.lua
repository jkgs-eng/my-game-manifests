-- Auto-Generated Blueprint for We Were Here Together
local manifest = {
    appid = 865360,
    name = "We Were Here Together",
    status = "Custom Autopilot Build"
}
return manifest

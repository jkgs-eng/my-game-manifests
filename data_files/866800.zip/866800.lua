-- Auto-Generated Blueprint for The Walking Dead: The Final Season
local manifest = {
    appid = 866800,
    name = "The Walking Dead: The Final Season",
    status = "Custom Autopilot Build"
}
return manifest

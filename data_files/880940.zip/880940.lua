-- Auto-Generated Blueprint for Pummel Party
local manifest = {
    appid = 880940,
    name = "Pummel Party",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Noita
local manifest = {
    appid = 881100,
    name = "Noita",
    status = "Custom Autopilot Build"
}
return manifest

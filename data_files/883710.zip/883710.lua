-- Auto-Generated Blueprint for Resident Evil 2
local manifest = {
    appid = 883710,
    name = "Resident Evil 2",
    status = "Custom Autopilot Build"
}
return manifest

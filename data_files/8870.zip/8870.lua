-- Auto-Generated Blueprint for BioShock Infinite
local manifest = {
    appid = 8870,
    name = "BioShock Infinite",
    status = "Custom Autopilot Build"
}
return manifest

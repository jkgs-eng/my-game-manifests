-- Auto-Generated Blueprint for Valheim
local manifest = {
    appid = 892970,
    name = "Valheim",
    status = "Custom Autopilot Build"
}
return manifest

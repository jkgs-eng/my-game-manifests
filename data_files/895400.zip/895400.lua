-- Auto-Generated Blueprint for Deadside
local manifest = {
    appid = 895400,
    name = "Deadside",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for The Survivalists
local manifest = {
    appid = 897450,
    name = "The Survivalists",
    status = "Custom Autopilot Build"
}
return manifest

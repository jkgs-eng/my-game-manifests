-- Auto-Generated Blueprint for GOD EATER 3
local manifest = {
    appid = 899440,
    name = "GOD EATER 3",
    status = "Custom Autopilot Build"
}
return manifest

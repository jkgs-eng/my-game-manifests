-- Auto-Generated Blueprint for Heave Ho
local manifest = {
    appid = 905340,
    name = "Heave Ho",
    status = "Custom Autopilot Build"
}
return manifest

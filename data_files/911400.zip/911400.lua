-- Auto-Generated Blueprint for Assassin's Creed® III Remastered
local manifest = {
    appid = 911400,
    name = "Assassin's Creed® III Remastered",
    status = "Custom Autopilot Build"
}
return manifest

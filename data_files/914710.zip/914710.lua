-- Auto-Generated Blueprint for Cat Quest II
local manifest = {
    appid = 914710,
    name = "Cat Quest II",
    status = "Custom Autopilot Build"
}
return manifest

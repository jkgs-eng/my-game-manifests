-- Auto-Generated Blueprint for Midnight Ghost Hunt
local manifest = {
    appid = 915810,
    name = "Midnight Ghost Hunt",
    status = "Custom Autopilot Build"
}
return manifest

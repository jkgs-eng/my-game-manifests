-- Auto-Generated Blueprint for Dead Island 2
local manifest = {
    appid = 934700,
    name = "Dead Island 2",
    status = "Custom Autopilot Build"
}
return manifest

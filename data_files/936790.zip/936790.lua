-- Auto-Generated Blueprint for Life is Strange: True Colors
local manifest = {
    appid = 936790,
    name = "Life is Strange: True Colors",
    status = "Custom Autopilot Build"
}
return manifest

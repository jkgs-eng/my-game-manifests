-- Auto-Generated Blueprint for The Dark Pictures Anthology: Man of Medan
local manifest = {
    appid = 939850,
    name = "The Dark Pictures Anthology: Man of Medan",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Far Cry® New Dawn
local manifest = {
    appid = 939960,
    name = "Far Cry® New Dawn",
    status = "Custom Autopilot Build"
}
return manifest

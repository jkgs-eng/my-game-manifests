-- Auto-Generated Blueprint for Among Us
local manifest = {
    appid = 945360,
    name = "Among Us",
    status = "Custom Autopilot Build"
}
return manifest

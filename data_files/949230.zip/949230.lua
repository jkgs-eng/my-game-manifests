-- Auto-Generated Blueprint for Cities: Skylines II
local manifest = {
    appid = 949230,
    name = "Cities: Skylines II",
    status = "Custom Autopilot Build"
}
return manifest

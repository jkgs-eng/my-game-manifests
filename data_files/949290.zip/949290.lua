-- Auto-Generated Blueprint for Winkeltje: The Little Shop
local manifest = {
    appid = 949290,
    name = "Winkeltje: The Little Shop",
    status = "Custom Autopilot Build"
}
return manifest

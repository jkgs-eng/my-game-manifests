-- Auto-Generated Blueprint for Resident Evil 3
local manifest = {
    appid = 952060,
    name = "Resident Evil 3",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Heavy Rain
local manifest = {
    appid = 960910,
    name = "Heavy Rain",
    status = "Custom Autopilot Build"
}
return manifest

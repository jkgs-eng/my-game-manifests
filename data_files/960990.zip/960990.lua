-- Auto-Generated Blueprint for Beyond: Two Souls
local manifest = {
    appid = 960990,
    name = "Beyond: Two Souls",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Skater XL - The Ultimate Skateboarding Game
local manifest = {
    appid = 962730,
    name = "Skater XL - The Ultimate Skateboarding Game",
    status = "Custom Autopilot Build"
}
return manifest

-- Auto-Generated Blueprint for Pacify
local manifest = {
    appid = 967050,
    name = "Pacify",
    status = "Custom Autopilot Build"
}
return manifest

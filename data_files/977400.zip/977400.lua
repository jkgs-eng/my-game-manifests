-- Auto-Generated Blueprint for Cell to Singularity - Evolution Never Ends
local manifest = {
    appid = 977400,
    name = "Cell to Singularity - Evolution Never Ends",
    status = "Custom Autopilot Build"
}
return manifest

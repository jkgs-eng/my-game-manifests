-- Auto-Generated Blueprint for Streets of Rage 4
local manifest = {
    appid = 985890,
    name = "Streets of Rage 4",
    status = "Custom Autopilot Build"
}
return manifest

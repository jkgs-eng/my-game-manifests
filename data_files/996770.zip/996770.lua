-- Auto-Generated Blueprint for Moving Out
local manifest = {
    appid = 996770,
    name = "Moving Out",
    status = "Custom Autopilot Build"
}
return manifest
